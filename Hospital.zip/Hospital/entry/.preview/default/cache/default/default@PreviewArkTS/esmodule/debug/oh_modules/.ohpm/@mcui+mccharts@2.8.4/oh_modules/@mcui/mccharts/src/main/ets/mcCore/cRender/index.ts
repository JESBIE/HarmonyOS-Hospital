import CRender from "@normalized:N&&&@mcui/mccharts/src/main/ets/mcCore/cRender/class/crender.class&2.8.4";
import { extendNewGraph } from "@normalized:N&&&@mcui/mccharts/src/main/ets/mcCore/cRender/config/graphs&2.8.4";
export { CRender, extendNewGraph };
export default CRender;
