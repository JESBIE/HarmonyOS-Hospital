if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Get_Nurse_Params {
    name?: string;
    age?: number;
    gender?: string;
    group_id?: number;
    addNurse?;
}
import type relationalStore from "@ohos:data.relationalStore";
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
class Get_Nurse extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new ObservedPropertySimplePU("11", this, "name");
        this.__age = new ObservedPropertySimplePU(0, this, "age");
        this.__gender = new ObservedPropertySimplePU("11", this, "gender");
        this.__group_id = new ObservedPropertySimplePU(0, this, "group_id");
        this.addNurse = () => {
            const valueBucket: relationalStore.ValuesBucket = {
                'NAME': this.name,
                'AGE': this.age,
                'GENDER': this.gender,
                'GROUP_ID': this.group_id
            };
            DButil.insertDB('NURSES', valueBucket);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Get_Nurse_Params) {
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
        if (params.gender !== undefined) {
            this.gender = params.gender;
        }
        if (params.group_id !== undefined) {
            this.group_id = params.group_id;
        }
        if (params.addNurse !== undefined) {
            this.addNurse = params.addNurse;
        }
    }
    updateStateVars(params: Get_Nurse_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__gender.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__gender.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // @State nid:number=0
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: ObservedPropertySimplePU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __gender: ObservedPropertySimplePU<string>;
    get gender() {
        return this.__gender.get();
    }
    set gender(newValue: string) {
        this.__gender.set(newValue);
    }
    private __group_id: ObservedPropertySimplePU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    private addNurse;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/get_Nurse.ets(25:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入护士姓名' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Nurse.ets(27:7)", "entry");
            TextInput.onChange((value: string) => {
                this.name = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入护士年龄' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Nurse.ets(32:7)", "entry");
            TextInput.onChange((value: string) => {
                this.age = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入护士性别' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Nurse.ets(37:7)", "entry");
            TextInput.onChange((value: string) => {
                this.gender = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入护士科室' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Nurse.ets(42:7)", "entry");
            TextInput.onChange((value: string) => {
                this.group_id = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认添加护士信息");
            Button.debugLine("entry/src/main/ets/pages/get_Nurse.ets(47:7)", "entry");
            Button.onClick(this.addNurse);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Get_Nurse";
    }
}
registerNamedRoute(() => new Get_Nurse(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_Nurse", pageFullPath: "entry/src/main/ets/pages/get_Nurse", integratedHsp: "false", moduleType: "followWithHap" });
