if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Patient_Params {
    Patients?: PatientModel[];
    findPatientDB?;
}
interface Patient_view_Params {
    name?: string;
    age?: number;
    gender?: string;
}
import type { PatientModel } from '../viewmodel/PatientModel';
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
class Patient_view extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__gender = new SynchedPropertySimpleOneWayPU(params.gender, this, "gender");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_view_Params) {
    }
    updateStateVars(params: Patient_view_Params) {
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__gender.reset(params.gender);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__gender.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__gender.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __gender: SynchedPropertySimpleOneWayPU<string>;
    get gender() {
        return this.__gender.get();
    }
    set gender(newValue: string) {
        this.__gender.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Patient.ets(11:5)", "entry");
            Column.width('90%');
            Column.height(60);
            Column.backgroundColor(Color.Gray);
            Column.borderRadius(4);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/Patient.ets(12:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.age));
            Text.debugLine("entry/src/main/ets/pages/Patient.ets(13:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.gender);
            Text.debugLine("entry/src/main/ets/pages/Patient.ets(14:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Patient extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Patients = new ObservedPropertyObjectPU([], this, "Patients");
        this.findPatientDB = async () => {
            this.Patients = await DButil.query_Patient_DB(['PID', 'NAME', 'AGE', 'GENDER'], 'PATIENTS');
            console.log(`数据库的结果为${JSON.stringify(this.Patients)}`);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_Params) {
        if (params.Patients !== undefined) {
            this.Patients = params.Patients;
        }
        if (params.findPatientDB !== undefined) {
            this.findPatientDB = params.findPatientDB;
        }
    }
    updateStateVars(params: Patient_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Patients.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Patients.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Patients: ObservedPropertyObjectPU<PatientModel[]>;
    get Patients() {
        return this.__Patients.get();
    }
    set Patients(newValue: PatientModel[]) {
        this.__Patients.set(newValue);
    }
    aboutToAppear(): void {
        console.log("加载数据库");
        this.findPatientDB();
        console.log("加载完毕");
    }
    private findPatientDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Patient.ets(42:7)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Patient.ets(43:9)", "entry");
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/Patient.ets(45:13)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new Patient_view(this, { name: item.name, age: item.age, gender: item.gender }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Patient.ets", line: 46, col: 15 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            name: item.name,
                                            age: item.age,
                                            gender: item.gender
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        name: item.name, age: item.age, gender: item.gender
                                    });
                                }
                            }, { name: "Patient_view" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.Patients, forEachItemGenFunction, (item: PatientModel) => JSON.stringify(item.pid), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Patient";
    }
}
registerNamedRoute(() => new Patient(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Patient", pageFullPath: "entry/src/main/ets/pages/Patient", integratedHsp: "false", moduleType: "followWithHap" });
