import type { Context } from "@ohos:abilityAccessCtrl";
import relationalStore from "@ohos:data.relationalStore";
import type { BusinessError } from "@ohos:base";
import { DoctorModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/DoctorModel&";
import { UserModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/UserModel&";
import { PatientModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/PatientModel&";
import { DiagnoseModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/DiagnoseModel&";
import { NurseModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/NurseModel&";
import { MissionLogModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/MissionLogModel&";
import { MissionModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/MissionModel&";
class DButils {
    private rdbStore: relationalStore.RdbStore | null = null;
    /**
     *
     * @param context 上下文对象
     * @param tableName 创建表的名字
     */
    initDB(context: Context) {
        const STORE_CONFIG: relationalStore.StoreConfig = {
            // 初始化数据库配置
            name: 'Hospital.db',
            securityLevel: relationalStore.SecurityLevel.S3,
            encrypt: false,
            customDir: 'customDir/subCustomDir',
            isReadOnly: false // 可选参数，指定数据库是否以只读方式打开。该参数默认为false，表示数据库可读可写。该参数为true时，只允许从数据库读取数据，不允许对数据库进行写操作，否则会返回错误码801。
        };
        // 定义SQL语句医生
        const SQL_CREATE_TABLE = `CREATE TABLE IF NOT EXISTS Doctor
    (ID INTEGER PRIMARY KEY AUTOINCREMENT,
    NAME TEXT NOT NULL,
    AGE INTEGER,
    SALARY INTEGER,
    LEVEL TEXT,
    GROUP_ID INTEGER)`; // 建表Sql语句, IDENTITY为bigint类型，sql中指定类型为UNLIMITED INT
        //病人
        const SQL_CREATE_TABLE2 = `CREATE TABLE IF NOT EXISTS PATIENTS
    (PID INTEGER PRIMARY KEY AUTOINCREMENT,
    NAME TEXT NOT NULL,
    AGE INTEGER,
    GENDER TEXT
    )`;
        //护士
        const SQL_CREATE_TABLE3 = `CREATE TABLE IF NOT EXISTS NURSES
    (NID INTEGER PRIMARY KEY AUTOINCREMENT,
    NAME TEXT NOT NULL,
    AGE INTEGER,
    GENDER TEXT,
    GROUP_ID INTEGER
    )`;
        //治疗
        const SQL_CREATE_TABLE4 = `CREATE TABLE IF NOT EXISTS DIAGNOSES
    (
    DIAGNOSE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    ID INTEGER NOT NULL,
    PID INTEGER NOT NULL,
    FOREIGN KEY (ID) REFERENCES Doctor (ID),
    FOREIGN KEY (PID) REFERENCES PATIENTS (PID)

    )`;
        const SQL_CREATE_TABLE5 = `CREATE TABLE IF NOT EXISTS MISSION
    (
    MID INTEGER PRIMARY KEY AUTOINCREMENT,
    ID INTEGER,
    NID INTEGER,
    GROUP_ID INTEGER,
    MISSION_TEXT TEXT,
    FOREIGN KEY (ID) REFERENCES Doctor (ID),
    FOREIGN KEY (NID) REFERENCES NURSES (NID),
    FOREIGN KEY (GROUP_ID) REFERENCES NURSES (GROUP_ID)
    );`;
        //后台管理用户
        const SQL_CREATE_TABLE1 = `CREATE TABLE IF NOT EXISTS USERS
    (ID INTEGER PRIMARY KEY AUTOINCREMENT,
    USERNAME TEXT,
    PASSWORD TEXT
    )`; // 建表Sql语句, IDENTITY为bigint类型，sql中指定类型为UNLIMITED INT
        const SQL_CREATE_TABLE6 = `CREATE TABLE IF NOT EXISTS MISSION_LOG (
    LOG_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    MID INTEGER,
    LOG_TIME TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    DETAILS TEXT
    )`;
        const SQL_CREATE_TABLE7 = `CREATE TABLE IF NOT EXISTS PATIENT_COUNT (
    COUNT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    MON INTEGER,
    TUE INTEGER,
    WEN INTEGER,
    THU INTEGER,
    FRI INTEGER,
    SAT INTEGER,
    SUN INTEGER
    )`;
        const createViewSql = `
    CREATE VIEW IF NOT EXISTS my_view AS
    SELECT NAME, SALARY FROM Doctor
    WHERE SALARY>300;
  `;
        //     const TRIGGER_SQL = `
        // CREATE TRIGGER IF NOT EXISTS after_appointment_insert
        // AFTER INSERT ON MISSION
        // BEGIN
        //
        //     INSERT INTO MISSION_LOG (MID, LOG_TIME,DETAILS) VALUES (NEW.MID, CURRENT_TIMESTAMP);
        // END;
        // `;
        const TRIGGER_SQL = `
CREATE TRIGGER IF NOT EXISTS after_appointment_insert
AFTER INSERT ON MISSION
FOR EACH ROW
BEGIN
    INSERT INTO MISSION_LOG (MID, LOG_TIME, DETAILS) VALUES (NEW.MID, DATETIME('now'),NEW.MISSION_TEXT);
END;
`;
        const INSERT_COUNT = `
    INSERT INTO PATIENT_COUNT (MON,TUE,WEN,THU,FRI,SAT,SUN)
    VALUES (0,0,0,0,0,0,0)`;
        const CREAT_INDEX_DOCTOR_NAME = `
    CREATE INDEX doctor_name ON Doctor (NAME);
    `;
        const CREAT_INDEX_DOCTOR_ID = `
    CREATE INDEX doctor_ID ON Doctor (ID);
    `;
        const CREAT_INDEX_PATIENT_NAME = `
    CREATE INDEX patient_ID ON Doctor (NAME);
    `;
        // 初始化数据库
        relationalStore.getRdbStore(context, STORE_CONFIG, (err, store) => {
            if (err) {
                console.error(`初始化数据库失败Failed to get RdbStore. Code:${err.code}, message:${err.message}`);
                return;
            }
            console.info('初始化数据库成功Succeeded in getting RdbStore.');
            this.rdbStore = store;
            // 创建数据表
            store.executeSql(SQL_CREATE_TABLE, (error) => {
                if (!error) {
                    console.log(`Doctor创建成功`);
                }
                else {
                    console.log(`Doctor创建失败，`);
                }
            });
            // 创建数据表
            store.executeSql(SQL_CREATE_TABLE1, (error) => {
                if (!error) {
                    console.log(`USERS创建成功`);
                }
                else {
                    console.log(`USERS创建失败，`);
                }
            });
            // 创建数据表
            store.executeSql(SQL_CREATE_TABLE2, (error) => {
                if (!error) {
                    console.log(`PATIENTS创建成功`);
                }
                else {
                    console.log(`PATIENTS创建失败，`);
                }
            });
            // 创建数据表
            store.executeSql(SQL_CREATE_TABLE3, (error) => {
                if (!error) {
                    console.log(`NURSES创建成功`);
                }
                else {
                    console.log(`NURSES创建失败，`);
                }
            });
            // 创建医生患者表
            store.executeSql(SQL_CREATE_TABLE4, (error) => {
                if (!error) {
                    console.log(`DIAGNOSES创建成功`);
                }
                else {
                    console.log(`DIAGNOSES创建失败，`);
                }
            });
            store.executeSql(SQL_CREATE_TABLE5, (error) => {
                if (!error) {
                    console.log(`MISSION创建成功`);
                }
                else {
                    console.log(`MISSION创建失败，${error.message}`);
                }
            });
            store.executeSql(createViewSql, (error) => {
                if (!error) {
                    console.log(`视图创建成功`);
                }
                else {
                    console.log(`视图创建失败，`);
                }
            });
            store.executeSql(SQL_CREATE_TABLE6, (error) => {
                if (!error) {
                    console.log(`MISSION_LOG创建成功`);
                }
                else {
                    console.log(`MISSION_LOG创建失败，`);
                }
            });
            store.executeSql(SQL_CREATE_TABLE7, (error) => {
                if (!error) {
                    console.log(`PATIENT_COUNT创建成功`);
                }
                else {
                    console.log(`PATIENT_COUNT创建失败，`);
                }
            });
            // 执行SQL语句来创建触发器
            store.executeSql(TRIGGER_SQL, (err) => {
                if (err) {
                    console.error(`触发器 failed, code is ${err.code}, message is ${err.message}`);
                    return;
                }
                console.info('Trigger created successfully');
            });
            store.executeSql(INSERT_COUNT, (err) => {
                if (err) {
                    console.error(`插入 failed, code is ${err.code}, message is ${err.message}`);
                    return;
                }
                console.info('初始化 created successfully');
            });
            store.executeSql(CREAT_INDEX_DOCTOR_NAME, (err) => {
                if (err) {
                    console.error(`无法创建索引1 failed, code is ${err.code}, message is ${err.message}`);
                    return;
                }
                console.info('创建索引1created successfully');
            });
            store.executeSql(CREAT_INDEX_DOCTOR_ID, (err) => {
                if (err) {
                    console.error(`无法创建索引2 failed, code is ${err.code}, message is ${err.message}`);
                    return;
                }
                console.info('索引2成功 created successfully');
            });
            store.executeSql(CREAT_INDEX_PATIENT_NAME, (err) => {
                if (err) {
                    console.error(`无法创建索引3 failed, code is ${err.code}, message is ${err.message}`);
                    return;
                }
                console.info('索引3成功 created successfully');
            });
        });
    }
    /**
     *
     * @param tableName
     */
    insertDB(tableName: string, value: relationalStore.ValuesBucket) {
        if (this.rdbStore !== null) {
            this.rdbStore.insert(tableName, value, (error: BusinessError, rowId: number) => {
                if (error) {
                    console.log(`往${tableName}里面添加失败${error.message}${error.data}`);
                    return;
                }
                console.log(`往${tableName}里面添加成功`);
            });
        }
    }
    deleteDB(tableName: string, id: number, name?: string) {
        let predict = new relationalStore.RdbPredicates(tableName);
        //筛选条件，根据ID删除
        predict.equalTo('ID', id);
        if (this.rdbStore !== null) {
            this.rdbStore.delete(predict, (err: BusinessError, rows: number) => {
                if (err) {
                    console.log('删除数据失败');
                    return;
                }
                console.log(`成功删除数据${rows}`);
            });
        }
    }
    deleteDB_name(tableName: string, name: string) {
        let predict = new relationalStore.RdbPredicates(tableName);
        //筛选条件，根据ID删除
        predict.equalTo('NAME', name);
        if (this.rdbStore !== null) {
            this.rdbStore.delete(predict, (err: BusinessError, rows: number) => {
                if (err) {
                    console.log('删除数据失败');
                    return;
                }
                console.log(`成功删除数据${rows}`);
            });
        }
    }
    updataDB(tableName: string, name: string, value: relationalStore.ValuesBucket) {
        let predict = new relationalStore.RdbPredicates(tableName);
        predict.equalTo('NAME', name);
        if (this.rdbStore !== undefined) {
            (this.rdbStore as relationalStore.RdbStore).update(value, predict, (err: BusinessError, rows: number) => {
                if (err) {
                    console.error(`Failed to update data. Code:${err.code}, message:${err.message}`);
                    return;
                }
                console.info(`Succeeded in updating data. row count: ${rows}`);
            });
        }
    }
    updataDB0(tableName: string, id: number, value: relationalStore.ValuesBucket) {
        let predict = new relationalStore.RdbPredicates(tableName);
        predict.equalTo('COUNT_ID', id);
        if (this.rdbStore !== undefined) {
            (this.rdbStore as relationalStore.RdbStore).update(value, predict, (err: BusinessError, rows: number) => {
                if (err) {
                    console.error(`Failed to update data. Code:${err.code}, message:${err.message}`);
                    return;
                }
                console.info(`Succeeded in updating data. row count: ${rows}`);
            });
        }
    }
    async queryDB(column: Array<string>, tableName: string, id?: number) {
        let predict = new relationalStore.RdbPredicates(tableName);
        if (id) {
            //筛选条件，根据ID删除
            predict.equalTo('ID', id);
        }
        //查询到的所有对象
        let Doctors: DoctorModel[] = [];
        //异步函数
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        //得到的是【数据库内容】需要进行转换
        while (resultSet.goToNextRow()) {
            let id = resultSet.getLong(resultSet.getColumnIndex('ID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let salary = resultSet.getLong(resultSet.getColumnIndex('SALARY'));
            let level = resultSet.getString(resultSet.getColumnIndex('LEVEL'));
            let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            const temp: DoctorModel = new DoctorModel();
            temp.id = id;
            temp.name = name;
            temp.age = age;
            temp.salary = salary;
            temp.level = level;
            temp.group_id = group_id;
            Doctors.push(temp);
        }
        //释放内存的结果集
        resultSet.close();
        return Doctors;
    }
    async query_Doctor_name(column: Array<string>, name: string) {
        let predict = new relationalStore.RdbPredicates('Doctor');
        predict.equalTo('NAME', name);
        let temp: DoctorModel = new DoctorModel();
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let id = resultSet.getLong(resultSet.getColumnIndex('ID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let salary = resultSet.getLong(resultSet.getColumnIndex('SALARY'));
            let level = resultSet.getString(resultSet.getColumnIndex('LEVEL'));
            let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            temp.id = id;
            temp.name = name;
            temp.age = age;
            temp.salary = salary;
            temp.level = level;
            temp.group_id = group_id;
        }
        return temp;
    }
    async query_User_DB(column: Array<string>, tableName: string, UserName: string, Password: string, id?: number) {
        let predict = new relationalStore.RdbPredicates(tableName);
        if (id) {
            //筛选条件，根据ID删除
            predict.equalTo('ID', id);
        }
        //查询到的所有对象
        // let Doctors:DoctorModel[]=[];
        let User: UserModel = new UserModel();
        //异步函数
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        //得到的是【数据库内容】需要进行转换
        while (resultSet.goToNextRow()) {
            // let id = resultSet.getLong(resultSet.getColumnIndex('ID'));
            // let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            // let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            // let salary = resultSet.getLong(resultSet.getColumnIndex('SALARY'));
            // let level = resultSet.getString(resultSet.getColumnIndex('LEVEL'));
            // let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            let username = resultSet.getString(resultSet.getColumnIndex('USERNAME'));
            let password = resultSet.getString(resultSet.getColumnIndex('PASSWORD'));
            const temp: UserModel = new UserModel();
            temp.username = username;
            temp.password = password;
            if (temp.username === UserName && temp.password === Password) {
                console.log("在数据库中找到了对应的用户");
                return 1;
            }
        }
        //释放内存的结果集
        resultSet.close();
        console.log("未能成功在数据库中找到对应的用户");
        return 0;
    }
    async query_Patient_DB(column: Array<string>, tableName: string, id?: number) {
        console.log("开始查找");
        let predict = new relationalStore.RdbPredicates(tableName);
        if (id) {
            //筛选条件，根据ID删除
            predict.equalTo('PID', id);
        }
        let Patients: PatientModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            // console.log("进入循环")
            let pid = resultSet.getLong(resultSet.getColumnIndex('PID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let gender = resultSet.getString(resultSet.getColumnIndex('GENDER'));
            const temp: PatientModel = new PatientModel();
            temp.pid = pid;
            temp.name = name;
            temp.age = age;
            temp.gender = gender;
            Patients.push(temp);
            // console.log(`找到一个${pid}  ${name}`)
        }
        //释放内存的结果集
        resultSet.close();
        console.log("循环结束，返回结果");
        return Patients;
    }
    //患者查询预约医生
    async query_diagnoses(column: Array<string>, tableName: string, pid?: number, id?: number) {
        let predict = new relationalStore.RdbPredicates(tableName);
        if (id) {
            //筛选条件，根据ID删除
            predict.equalTo('DIAGNOSE_ID', id);
        }
        let Diagnose: DiagnoseModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let diagnose_id = resultSet.getLong(resultSet.getColumnIndex('DIAGNOSE_ID'));
            let pid1 = resultSet.getLong(resultSet.getColumnIndex('PID'));
            let id = resultSet.getLong(resultSet.getColumnIndex('ID'));
            const temp: DiagnoseModel = new DiagnoseModel();
            temp.diagnose_id = diagnose_id;
            temp.id = id;
            temp.pid = pid1;
            if (pid1 === pid) {
                Diagnose.push(temp);
            }
        }
        //释放内存的结果集
        resultSet.close();
        return Diagnose;
    }
    async queryDoctor(column: Array<string>, tableName: string, did?: number) {
        let predict = new relationalStore.RdbPredicates(tableName);
        //查询到的所有对象
        let Doctors: DoctorModel = new DoctorModel();
        //异步函数
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        //得到的是【数据库内容】需要进行转换
        while (resultSet.goToNextRow()) {
            let id = resultSet.getLong(resultSet.getColumnIndex('ID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let salary = resultSet.getLong(resultSet.getColumnIndex('SALARY'));
            let level = resultSet.getString(resultSet.getColumnIndex('LEVEL'));
            let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            const temp: DoctorModel = new DoctorModel();
            temp.id = id;
            temp.name = name;
            temp.age = age;
            temp.salary = salary;
            temp.level = level;
            temp.group_id = group_id;
            if (temp.id === did) {
                Doctors = temp;
            }
        }
        //释放内存的结果集
        resultSet.close();
        return Doctors;
    }
    //根据医生的编号查询病人还有多少，就是一个医生还需要问诊多少名病人
    async query_Dr_patient(column: Array<string>, tableName: string, id?: number) {
        let predict = new relationalStore.RdbPredicates(tableName);
        // if(id){
        //   //筛选条件，根据ID删除
        //   predict.equalTo('DIAGNOSE_ID',id);
        //
        // }
        let Diagnose: DiagnoseModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let diagnose_id = resultSet.getLong(resultSet.getColumnIndex('DIAGNOSE_ID'));
            let pid1 = resultSet.getLong(resultSet.getColumnIndex('PID'));
            let id1 = resultSet.getLong(resultSet.getColumnIndex('ID'));
            const temp: DiagnoseModel = new DiagnoseModel();
            temp.diagnose_id = diagnose_id;
            temp.id = id1;
            temp.pid = pid1;
            console.log(`预约信息${temp}`);
            if (id1 === id) {
                Diagnose.push(temp);
            }
        }
        //释放内存的结果集
        resultSet.close();
        return Diagnose;
    }
    async query_Nurse(column: Array<string>, name?: string, group_id?: number) {
        let predict = new relationalStore.RdbPredicates('NURSES');
        if (name) {
            predict.equalTo('NAME', name);
        }
        if (group_id) {
            predict.equalTo('GROUP_ID', group_id);
        }
        let nurses: NurseModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let nid = resultSet.getLong(resultSet.getColumnIndex('NID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let gender = resultSet.getString(resultSet.getColumnIndex('GENDER'));
            let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            const temp: NurseModel = new NurseModel();
            temp.nid = nid;
            temp.name = name;
            temp.age = age;
            temp.gender = gender;
            temp.group_id = group_id;
            nurses.push(temp);
        }
        resultSet.close();
        return nurses;
    }
    async query_Nurse_group(column: Array<string>, group_id?: number) {
        let predict = new relationalStore.RdbPredicates('NURSES');
        if (group_id) {
            predict.equalTo('GROUP_ID', group_id);
        }
        let nurses: NurseModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let nid = resultSet.getLong(resultSet.getColumnIndex('NID'));
            let name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            let age = resultSet.getLong(resultSet.getColumnIndex('AGE'));
            let gender = resultSet.getString(resultSet.getColumnIndex('GENDER'));
            let group_id = resultSet.getLong(resultSet.getColumnIndex('GROUP_ID'));
            const temp: NurseModel = new NurseModel();
            temp.nid = nid;
            temp.name = name;
            temp.age = age;
            temp.gender = gender;
            temp.group_id = group_id;
            nurses.push(temp);
        }
        resultSet.close();
        return nurses;
    }
    async query_Mission_log(column: Array<string>) {
        let predict = new relationalStore.RdbPredicates('MISSION_LOG');
        let logs: MissionLogModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let log_id = resultSet.getLong(resultSet.getColumnIndex('LOG_ID'));
            let time = resultSet.getString(resultSet.getColumnIndex('LOG_TIME'));
            let details = resultSet.getString(resultSet.getColumnIndex('DETAILS'));
            let temp: MissionLogModel = new MissionLogModel();
            temp.log_id = log_id;
            temp.details = details;
            temp.log_time = time;
            logs.push(temp);
        }
        resultSet.close();
        return logs;
    }
    async query_Mission(column: Array<string>) {
        let predict = new relationalStore.RdbPredicates('MISSION');
        let missions: MissionModel[] = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, column);
        while (resultSet.goToNextRow()) {
            let mid = resultSet.getLong(resultSet.getColumnIndex('MID'));
            let mission_text = resultSet.getString(resultSet.getColumnIndex('MISSION_TEXT'));
            let temp: MissionModel = new MissionModel();
            temp.mid = mid;
            temp.mission_text = mission_text;
            missions.push(temp);
        }
        resultSet.close();
        return missions;
    }
    async query_count() {
        let predict = new relationalStore.RdbPredicates('PATIENT_COUNT');
        let count: Array<number> = [];
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, ['MON', 'TUE', 'WEN', 'THU', 'FRI', 'SAT', 'SUN']);
        while (resultSet.goToNextRow()) {
            let mon = resultSet.getLong(resultSet.getColumnIndex('MON'));
            let tue = resultSet.getLong(resultSet.getColumnIndex('TUE'));
            let wen = resultSet.getLong(resultSet.getColumnIndex('WEN'));
            let thu = resultSet.getLong(resultSet.getColumnIndex('THU'));
            let fri = resultSet.getLong(resultSet.getColumnIndex('FRI'));
            let sat = resultSet.getLong(resultSet.getColumnIndex('SAT'));
            let sun = resultSet.getLong(resultSet.getColumnIndex('SUN'));
            count[0] = mon;
            count[1] = tue;
            count[2] = wen;
            count[3] = thu;
            count[4] = fri;
            count[5] = sat;
            count[6] = sun;
            break;
        }
        return count;
    }
    //根据病人的姓名查找PID
    async query_patient_id(name: string) {
        console.log("进入查找");
        let predict = new relationalStore.RdbPredicates('PATIENTS');
        const resultSet = await (this.rdbStore as relationalStore.RdbStore).query(predict, ['PID']);
        let pid: number = 0;
        while (resultSet.goToNextRow()) {
            console.log("开找！！！！！！！！！");
            let patient_id = resultSet.getLong(resultSet.getColumnIndex('PID'));
            let patient_name = resultSet.getString(resultSet.getColumnIndex('NAME'));
            if (patient_name === name) {
                console.log("找到了！！！！！");
                pid = patient_id;
            }
        }
        resultSet.close();
        return pid;
    }
}
const DButil = new DButils();
export { DButil };
