if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Patient_count_Params {
    data1?: number[];
    findDoctorDB?;
    defOptions?: Options;
}
import { Options } from "@normalized:N&&&@mcui/mccharts/index&2.8.4";
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type relationalStore from "@ohos:data.relationalStore";
import router from "@ohos:router";
class Patient_count extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__data1 = new ObservedPropertyObjectPU([], this, "data1");
        this.findDoctorDB = async () => {
            this.data1 = await DButil.query_count();
            AppStorage.setOrCreate('week', this.data1);
            console.log(`患者人数的结果为${JSON.stringify(this.data1)}`);
        };
        this.__defOptions = new ObservedPropertyObjectPU(new Options({
            xAxis: {
                data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
            },
            yAxis: {
                name: '患者人数'
            },
            series: [
                {
                    name: "每日预约人数",
                    data: this.data1
                }
            ]
        }), this, "defOptions");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_count_Params) {
        if (params.data1 !== undefined) {
            this.data1 = params.data1;
        }
        if (params.findDoctorDB !== undefined) {
            this.findDoctorDB = params.findDoctorDB;
        }
        if (params.defOptions !== undefined) {
            this.defOptions = params.defOptions;
        }
    }
    updateStateVars(params: Patient_count_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__data1.purgeDependencyOnElmtId(rmElmtId);
        this.__defOptions.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__data1.aboutToBeDeleted();
        this.__defOptions.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __data1: ObservedPropertyObjectPU<number[]>;
    get data1() {
        return this.__data1.get();
    }
    set data1(newValue: number[]) {
        this.__data1.set(newValue);
    }
    aboutToAppear(): void {
        this.findDoctorDB();
    }
    private findDoctorDB;
    private __defOptions: ObservedPropertyObjectPU<Options>;
    get defOptions() {
        return this.__defOptions.get();
    }
    set defOptions(newValue: Options) {
        this.__defOptions.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Patient_count.ets(36:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周一人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(38:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[0] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周二人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(42:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[1] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周三人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(46:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[2] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周四人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(50:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[3] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周五人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(54:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[4] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周六人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(58:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[5] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入周日人数' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_count.ets(62:7)", "entry");
            TextInput.onChange((value: string) => {
                this.data1[6] = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认更新");
            Button.debugLine("entry/src/main/ets/pages/Patient_count.ets(67:7)", "entry");
            Button.onClick(() => {
                const valueBucket1: relationalStore.ValuesBucket = {
                    'MON': this.data1[0],
                    'TUE': this.data1[1],
                    'WEN': this.data1[2],
                    'THU': this.data1[3],
                    'FRI': this.data1[4],
                    'SAT': this.data1[5],
                    'SUN': this.data1[6]
                };
                DButil.updataDB0('PATIENT_COUNT', 1, valueBucket1);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("不更新直接查看");
            Button.debugLine("entry/src/main/ets/pages/Patient_count.ets(81:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Count"
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Patient_count";
    }
}
registerNamedRoute(() => new Patient_count(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Patient_count", pageFullPath: "entry/src/main/ets/pages/Patient_count", integratedHsp: "false", moduleType: "followWithHap" });
