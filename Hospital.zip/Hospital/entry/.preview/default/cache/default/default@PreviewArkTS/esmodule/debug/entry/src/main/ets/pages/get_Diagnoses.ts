if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Get_Diagnoses_Params {
    ID?: number;
    PID?: number;
    addDiagnoses?;
}
import type relationalStore from "@ohos:data.relationalStore";
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
class Get_Diagnoses extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__ID = new ObservedPropertySimplePU(0, this, "ID");
        this.__PID = new ObservedPropertySimplePU(0, this, "PID");
        this.addDiagnoses = () => {
            const valueBucket: relationalStore.ValuesBucket = {
                'ID': this.ID,
                'PID': this.PID
            };
            DButil.insertDB('DIAGNOSES', valueBucket);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Get_Diagnoses_Params) {
        if (params.ID !== undefined) {
            this.ID = params.ID;
        }
        if (params.PID !== undefined) {
            this.PID = params.PID;
        }
        if (params.addDiagnoses !== undefined) {
            this.addDiagnoses = params.addDiagnoses;
        }
    }
    updateStateVars(params: Get_Diagnoses_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__ID.purgeDependencyOnElmtId(rmElmtId);
        this.__PID.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__ID.aboutToBeDeleted();
        this.__PID.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __ID: ObservedPropertySimplePU<number>;
    get ID() {
        return this.__ID.get();
    }
    set ID(newValue: number) {
        this.__ID.set(newValue);
    }
    private __PID: ObservedPropertySimplePU<number>;
    get PID() {
        return this.__PID.get();
    }
    set PID(newValue: number) {
        this.__PID.set(newValue);
    }
    private addDiagnoses;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/get_Diagnoses.ets(17:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.padding({ top: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入预约医生编号' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Diagnoses.ets(18:7)", "entry");
            TextInput.onChange((value: string) => {
                this.ID = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入预约患者编号' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Diagnoses.ets(24:7)", "entry");
            TextInput.onChange((value: string) => {
                this.PID = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认添加预约");
            Button.debugLine("entry/src/main/ets/pages/get_Diagnoses.ets(29:7)", "entry");
            Button.onClick(this.addDiagnoses);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Get_Diagnoses";
    }
}
registerNamedRoute(() => new Get_Diagnoses(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_Diagnoses", pageFullPath: "entry/src/main/ets/pages/get_Diagnoses", integratedHsp: "false", moduleType: "followWithHap" });
