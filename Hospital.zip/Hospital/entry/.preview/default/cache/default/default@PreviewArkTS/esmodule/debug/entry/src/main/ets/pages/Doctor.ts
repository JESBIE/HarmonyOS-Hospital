if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Doctor_Params {
    Doctors?: DoctorModel[];
    name_Picked?: string;
    findDoctorDB?;
    textValue?: string;
    inputValue?: string;
    dialogController?: CustomDialogController | null;
}
interface Doctor_view_Params {
    did?: number;
    name?: string;
    age?: number;
    level?: string;
    group_id?: number;
}
interface CustomDialogExample_Params {
    controller?: CustomDialogController;
    name?: string;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DoctorModel } from '../viewmodel/DoctorModel';
import router from "@ohos:router";
class CustomDialogExample extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CustomDialogExample_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.name === undefined) {
            this.__name.set("");
        }
    }
    updateStateVars(params: CustomDialogExample_Params) {
        this.__name.reset(params.name);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller?: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Doctor.ets(12:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Whether to change a text?');
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(13:7)", "entry");
            Text.fontSize(16);
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Doctor.ets(18:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("删除");
            Button.debugLine("entry/src/main/ets/pages/Doctor.ets(19:9)", "entry");
            Button.onClick(() => {
                this.controller?.close();
                console.log(`弹窗内得到的${this.name}`);
                DButil.deleteDB_name('Doctor', this.name);
                router.pushUrl({
                    url: "pages/ManagerIndex"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("取消");
            Button.debugLine("entry/src/main/ets/pages/Doctor.ets(28:9)", "entry");
            Button.onClick(() => {
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Doctor_view extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__did = new SynchedPropertySimpleOneWayPU(params.did, this, "did");
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__level = new SynchedPropertySimpleOneWayPU(params.level, this, "level");
        this.__group_id = new SynchedPropertySimpleOneWayPU(params.group_id, this, "group_id");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Doctor_view_Params) {
    }
    updateStateVars(params: Doctor_view_Params) {
        this.__did.reset(params.did);
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__level.reset(params.level);
        this.__group_id.reset(params.group_id);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__did.purgeDependencyOnElmtId(rmElmtId);
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__level.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__did.aboutToBeDeleted();
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__level.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __did: SynchedPropertySimpleOneWayPU<number>;
    get did() {
        return this.__did.get();
    }
    set did(newValue: number) {
        this.__did.set(newValue);
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __level: SynchedPropertySimpleOneWayPU<string>;
    get level() {
        return this.__level.get();
    }
    set level(newValue: string) {
        this.__level.set(newValue);
    }
    private __group_id?: SynchedPropertySimpleOneWayPU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Doctor.ets(45:5)", "entry");
            Column.width('90%');
            Column.height(100);
            Column.backgroundColor(Color.Gray);
            Column.borderRadius(4);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`医生编号    ${JSON.stringify(this.did)}`);
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(46:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`医生姓名    ${this.name}`);
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(47:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`医生年龄    ${JSON.stringify(this.age)}`);
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(48:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`医生职称    ${this.level}`);
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(49:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`医生科室号   ${JSON.stringify(this.group_id)}`);
            Text.debugLine("entry/src/main/ets/pages/Doctor.ets(50:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Doctors = new ObservedPropertyObjectPU([], this, "Doctors");
        this.__name_Picked = new ObservedPropertySimplePU("", this, "name_Picked");
        this.findDoctorDB = async () => {
            this.Doctors = await DButil.queryDB(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], 'Doctor');
            console.log(`数据库的结果为${JSON.stringify(this.Doctors)}`);
        };
        this.__textValue = new ObservedPropertySimplePU('', this, "textValue");
        this.__inputValue = new ObservedPropertySimplePU('click me', this, "inputValue");
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomDialogExample(this, { name: this.name_Picked }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/Doctor.ets", line: 82, col: 14 });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        name: this.name_Picked
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            openAnimation: {
                duration: 1200,
                curve: Curve.Friction,
                delay: 500,
                playMode: PlayMode.Alternate,
                onFinish: () => {
                    console.info('play end');
                }
            },
            autoCancel: true,
            alignment: DialogAlignment.Bottom,
            offset: { dx: 0, dy: -20 },
            gridCount: 4,
            customStyle: false,
            backgroundColor: 0xd9ffffff,
            cornerRadius: 10
        }, this);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Doctor_Params) {
        if (params.Doctors !== undefined) {
            this.Doctors = params.Doctors;
        }
        if (params.name_Picked !== undefined) {
            this.name_Picked = params.name_Picked;
        }
        if (params.findDoctorDB !== undefined) {
            this.findDoctorDB = params.findDoctorDB;
        }
        if (params.textValue !== undefined) {
            this.textValue = params.textValue;
        }
        if (params.inputValue !== undefined) {
            this.inputValue = params.inputValue;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params: Doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Doctors.purgeDependencyOnElmtId(rmElmtId);
        this.__name_Picked.purgeDependencyOnElmtId(rmElmtId);
        this.__textValue.purgeDependencyOnElmtId(rmElmtId);
        this.__inputValue.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Doctors.aboutToBeDeleted();
        this.__name_Picked.aboutToBeDeleted();
        this.__textValue.aboutToBeDeleted();
        this.__inputValue.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Doctors: ObservedPropertyObjectPU<DoctorModel[]>;
    get Doctors() {
        return this.__Doctors.get();
    }
    set Doctors(newValue: DoctorModel[]) {
        this.__Doctors.set(newValue);
    }
    private __name_Picked: ObservedPropertySimplePU<string>;
    get name_Picked() {
        return this.__name_Picked.get();
    }
    set name_Picked(newValue: string) {
        this.__name_Picked.set(newValue);
    }
    aboutToAppear(): void {
        this.findDoctorDB();
    }
    private findDoctorDB;
    private __textValue: ObservedPropertySimplePU<string>;
    get textValue() {
        return this.__textValue.get();
    }
    set textValue(newValue: string) {
        this.__textValue.set(newValue);
    }
    private __inputValue: ObservedPropertySimplePU<string>;
    get inputValue() {
        return this.__inputValue.get();
    }
    set inputValue(newValue: string) {
        this.__inputValue.set(newValue);
    }
    private dialogController: CustomDialogController | null;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/pages/Doctor.ets(101:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/Doctor.ets(103:7)", "entry");
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/Doctor.ets(105:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            __Common__.create();
                            __Common__.onClick(() => {
                                console.log(`点击了${item.name}`);
                                this.name_Picked = item.name;
                                if (this.dialogController != null) {
                                    this.dialogController.open();
                                }
                            });
                        }, __Common__);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new Doctor_view(this, { did: item.id, name: item.name, age: item.age, level: item.level, group_id: item.group_id }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Doctor.ets", line: 106, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            did: item.id,
                                            name: item.name,
                                            age: item.age,
                                            level: item.level,
                                            group_id: item.group_id
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        did: item.id, name: item.name, age: item.age, level: item.level, group_id: item.group_id
                                    });
                                }
                            }, { name: "Doctor_view" });
                        }
                        __Common__.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.Doctors, forEachItemGenFunction, (item: DoctorModel) => JSON.stringify(item.id), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Doctor";
    }
}
registerNamedRoute(() => new Doctor(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Doctor", pageFullPath: "entry/src/main/ets/pages/Doctor", integratedHsp: "false", moduleType: "followWithHap" });
