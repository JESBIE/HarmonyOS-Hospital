if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Updata_Doctor_Params {
    name?: string;
    age?: number;
    salary?: number;
    level?: string;
    group_id?: number;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type relationalStore from "@ohos:data.relationalStore";
class Updata_Doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new ObservedPropertySimplePU("", this, "name");
        this.__age = new ObservedPropertySimplePU(0, this, "age");
        this.__salary = new ObservedPropertySimplePU(0, this, "salary");
        this.__level = new ObservedPropertySimplePU("", this, "level");
        this.__group_id = new ObservedPropertySimplePU(0, this, "group_id");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Updata_Doctor_Params) {
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
        if (params.salary !== undefined) {
            this.salary = params.salary;
        }
        if (params.level !== undefined) {
            this.level = params.level;
        }
        if (params.group_id !== undefined) {
            this.group_id = params.group_id;
        }
    }
    updateStateVars(params: Updata_Doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__salary.purgeDependencyOnElmtId(rmElmtId);
        this.__level.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__salary.aboutToBeDeleted();
        this.__level.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __name: ObservedPropertySimplePU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: ObservedPropertySimplePU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __salary: ObservedPropertySimplePU<number>;
    get salary() {
        return this.__salary.get();
    }
    set salary(newValue: number) {
        this.__salary.set(newValue);
    }
    private __level: ObservedPropertySimplePU<string>;
    get level() {
        return this.__level.get();
    }
    set level(newValue: string) {
        this.__level.set(newValue);
    }
    private __group_id: ObservedPropertySimplePU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(13:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入需更改的医生姓名' });
            TextInput.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(14:7)", "entry");
            TextInput.onChange((value: string) => {
                this.name = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入需更改的医生年龄' });
            TextInput.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(19:7)", "entry");
            TextInput.onChange((value: string) => {
                this.age = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入需更改的医生工资' });
            TextInput.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(24:7)", "entry");
            TextInput.onChange((value: string) => {
                this.salary = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入需更改的医生职称' });
            TextInput.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(29:7)", "entry");
            TextInput.onChange((value: string) => {
                this.level = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入需更改的医生组号' });
            TextInput.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(34:7)", "entry");
            TextInput.onChange((value: string) => {
                this.group_id = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认修改");
            Button.debugLine("entry/src/main/ets/pages/updata_Doctor.ets(39:7)", "entry");
            Button.onClick(() => {
                const valueBucket1: relationalStore.ValuesBucket = {
                    'NAME': this.name,
                    'AGE': this.age,
                    'SALARY': this.salary,
                    'LEVEL': this.level,
                    'GROUP_ID': this.group_id
                };
                DButil.updataDB('Doctor', this.name, valueBucket1);
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Updata_Doctor";
    }
}
registerNamedRoute(() => new Updata_Doctor(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/updata_Doctor", pageFullPath: "entry/src/main/ets/pages/updata_Doctor", integratedHsp: "false", moduleType: "followWithHap" });
