if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Page_Params {
    uid?: string;
    password?: string;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import router from "@ohos:router";
class Login_Page extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__uid = new ObservedPropertySimplePU("", this, "uid");
        this.__password = new ObservedPropertySimplePU("", this, "password");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Page_Params) {
        if (params.uid !== undefined) {
            this.uid = params.uid;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params: Login_Page_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__uid.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__uid.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __uid: ObservedPropertySimplePU<string>;
    get uid() {
        return this.__uid.get();
    }
    set uid(newValue: string) {
        this.__uid.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/Login_Page.ets(11:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#B4CDCD');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/Login_Page.ets(12:7)", "entry");
            TextInput.onChange((value: string) => {
                this.uid = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入用户密码' });
            TextInput.debugLine("entry/src/main/ets/pages/Login_Page.ets(17:7)", "entry");
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 80 });
            Row.debugLine("entry/src/main/ets/pages/Login_Page.ets(22:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("登陆");
            Button.debugLine("entry/src/main/ets/pages/Login_Page.ets(23:9)", "entry");
            Button.onClick(async () => {
                const cunzai = await DButil.query_User_DB(['USERNAME', 'PASSWORD'], 'USERS', this.uid, this.password);
                if (cunzai === 1) {
                    router.pushUrl({
                        url: "pages/ManagerIndex"
                    });
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("注册");
            Button.debugLine("entry/src/main/ets/pages/Login_Page.ets(33:9)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_User"
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Login_Page.ets(41:7)", "entry");
            Image.height(200);
            Image.height(200);
        }, Image);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login_Page";
    }
}
registerNamedRoute(() => new Login_Page(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Login_Page", pageFullPath: "entry/src/main/ets/pages/Login_Page", integratedHsp: "false", moduleType: "followWithHap" });
