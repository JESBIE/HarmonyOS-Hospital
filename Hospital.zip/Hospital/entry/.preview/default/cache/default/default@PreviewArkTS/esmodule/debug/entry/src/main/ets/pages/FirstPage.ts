if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FirstPage_Params {
}
interface Manager_Params {
}
interface Patient_Params {
}
interface Doctor_Params {
}
import router from "@ohos:router";
class Doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Doctor_Params) {
    }
    updateStateVars(params: Doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/FirstPage.ets(6:5)", "entry");
            Row.backgroundColor('#C1FFC1');
            Row.height(60);
            Row.width('90%');
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(15);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/FirstPage.ets(8:7)", "entry");
            Image.width(30);
            Image.height(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("医护人员登陆");
            Text.debugLine("entry/src/main/ets/pages/FirstPage.ets(11:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Patient extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_Params) {
    }
    updateStateVars(params: Patient_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 53 });
            Row.debugLine("entry/src/main/ets/pages/FirstPage.ets(25:5)", "entry");
            Row.backgroundColor('#C1FFC1');
            Row.height(60);
            Row.width('90%');
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(15);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/FirstPage.ets(27:7)", "entry");
            Image.width(30);
            Image.height(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("病患登陆");
            Text.debugLine("entry/src/main/ets/pages/FirstPage.ets(30:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Manager extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Manager_Params) {
    }
    updateStateVars(params: Manager_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 39 });
            Row.debugLine("entry/src/main/ets/pages/FirstPage.ets(44:5)", "entry");
            Row.backgroundColor('#C1FFC1');
            Row.height(60);
            Row.width('90%');
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(15);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/FirstPage.ets(46:7)", "entry");
            Image.width(30);
            Image.height(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("管理员登陆");
            Text.debugLine("entry/src/main/ets/pages/FirstPage.ets(49:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class FirstPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FirstPage_Params) {
    }
    updateStateVars(params: FirstPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/FirstPage.ets(67:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#F0FFF0');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                router.pushUrl({
                    url: "pages/Login_Page"
                });
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Manager(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FirstPage.ets", line: 68, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Manager" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                router.pushUrl({
                    url: "pages/DoctorPage"
                });
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Doctor(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FirstPage.ets", line: 75, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Doctor" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                router.pushUrl({
                    url: "pages/Patient_Login"
                });
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Patient(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/FirstPage.ets", line: 84, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Patient" });
        }
        __Common__.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FirstPage";
    }
}
registerNamedRoute(() => new FirstPage(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/FirstPage", pageFullPath: "entry/src/main/ets/pages/FirstPage", integratedHsp: "false", moduleType: "followWithHap" });
