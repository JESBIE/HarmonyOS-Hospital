if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ManagerPage_Params {
}
class ManagerPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ManagerPage_Params) {
    }
    updateStateVars(params: ManagerPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ManagerPage.ets(6:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ManagerPage";
    }
}
registerNamedRoute(() => new ManagerPage(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/ManagerPage", pageFullPath: "entry/src/main/ets/pages/ManagerPage", integratedHsp: "false", moduleType: "followWithHap" });
