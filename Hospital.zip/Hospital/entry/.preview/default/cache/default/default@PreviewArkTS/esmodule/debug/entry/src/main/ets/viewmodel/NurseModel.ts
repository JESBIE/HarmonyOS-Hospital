export class NurseModel {
    nid?: number;
    name?: string;
    age?: number;
    gender?: string;
    group_id?: number;
}
