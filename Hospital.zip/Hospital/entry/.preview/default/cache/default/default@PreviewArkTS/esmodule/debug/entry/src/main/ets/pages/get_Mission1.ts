if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Get_Mission1_Params {
    mission_text?: string;
    doctor_id?: number;
    nid?: number;
    group_id?: number;
    insert_mission?;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type relationalStore from "@ohos:data.relationalStore";
class Get_Mission1 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__mission_text = new ObservedPropertySimplePU("", this, "mission_text");
        this.__doctor_id = this.createStorageProp('doctor_id', 0, "doctor_id");
        this.__nid = this.createStorageProp('nid', 0, "nid");
        this.__group_id = this.createStorageProp('group_id', 0, "group_id");
        this.insert_mission = () => {
            const valueBucket: relationalStore.ValuesBucket = {
                'ID': this.doctor_id,
                'NID': this.nid,
                'GROUP_ID': this.group_id,
                'MISSION_TEXT': this.mission_text
            };
            DButil.insertDB('MISSION', valueBucket);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Get_Mission1_Params) {
        if (params.mission_text !== undefined) {
            this.mission_text = params.mission_text;
        }
        if (params.insert_mission !== undefined) {
            this.insert_mission = params.insert_mission;
        }
    }
    updateStateVars(params: Get_Mission1_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__mission_text.purgeDependencyOnElmtId(rmElmtId);
        this.__doctor_id.purgeDependencyOnElmtId(rmElmtId);
        this.__nid.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__mission_text.aboutToBeDeleted();
        this.__doctor_id.aboutToBeDeleted();
        this.__nid.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __mission_text: ObservedPropertySimplePU<string>;
    get mission_text() {
        return this.__mission_text.get();
    }
    set mission_text(newValue: string) {
        this.__mission_text.set(newValue);
    }
    private __doctor_id: ObservedPropertyAbstractPU<number>;
    get doctor_id() {
        return this.__doctor_id.get();
    }
    set doctor_id(newValue: number) {
        this.__doctor_id.set(newValue);
    }
    private __nid: ObservedPropertyAbstractPU<number>;
    get nid() {
        return this.__nid.get();
    }
    set nid(newValue: number) {
        this.__nid.set(newValue);
    }
    private __group_id: ObservedPropertyAbstractPU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    private insert_mission;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 40 });
            Column.debugLine("entry/src/main/ets/pages/get_Mission1.ets(24:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入任务信息' });
            TextInput.debugLine("entry/src/main/ets/pages/get_Mission1.ets(25:7)", "entry");
            TextInput.onChange((value: string) => {
                this.mission_text = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认下发任务");
            Button.debugLine("entry/src/main/ets/pages/get_Mission1.ets(30:7)", "entry");
            Button.onClick(this.insert_mission);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Get_Mission1";
    }
}
registerNamedRoute(() => new Get_Mission1(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_Mission1", pageFullPath: "entry/src/main/ets/pages/get_Mission1", integratedHsp: "false", moduleType: "followWithHap" });
