export class PatientModel {
    pid?: number;
    name?: string;
    age?: number;
    gender?: string;
}
