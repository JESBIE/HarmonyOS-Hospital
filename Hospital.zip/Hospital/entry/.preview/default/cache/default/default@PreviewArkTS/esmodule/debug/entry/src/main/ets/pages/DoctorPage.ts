if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DoctorPage_Params {
    dname?: string;
    group_id?: number;
    Doctors?: DoctorModel[];
    cunzai?: number;
    doctoe_id?: number;
    d_mima?: number;
    findDoctorDB?;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DoctorModel } from '../viewmodel/DoctorModel';
import router from "@ohos:router";
class DoctorPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dname = new ObservedPropertySimplePU("", this, "dname");
        this.__group_id = new ObservedPropertySimplePU(0, this, "group_id");
        this.__Doctors = new ObservedPropertyObjectPU([], this, "Doctors");
        this.__cunzai = new ObservedPropertySimplePU(-1, this, "cunzai");
        this.__doctoe_id = new ObservedPropertySimplePU(0, this, "doctoe_id");
        this.__d_mima = new ObservedPropertySimplePU(0, this, "d_mima");
        this.findDoctorDB = async () => {
            this.Doctors = await DButil.queryDB(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], 'Doctor');
            console.log(`数据库的结果为${JSON.stringify(this.Doctors)}`);
            let index = this.Doctors.findIndex((item) => {
                this.group_id = item.group_id;
                this.doctoe_id = item.id;
                return item.name === this.dname;
            });
            if (index !== -1) {
                console.log("存在该医生信息");
                this.cunzai = index;
            }
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DoctorPage_Params) {
        if (params.dname !== undefined) {
            this.dname = params.dname;
        }
        if (params.group_id !== undefined) {
            this.group_id = params.group_id;
        }
        if (params.Doctors !== undefined) {
            this.Doctors = params.Doctors;
        }
        if (params.cunzai !== undefined) {
            this.cunzai = params.cunzai;
        }
        if (params.doctoe_id !== undefined) {
            this.doctoe_id = params.doctoe_id;
        }
        if (params.d_mima !== undefined) {
            this.d_mima = params.d_mima;
        }
        if (params.findDoctorDB !== undefined) {
            this.findDoctorDB = params.findDoctorDB;
        }
    }
    updateStateVars(params: DoctorPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dname.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
        this.__Doctors.purgeDependencyOnElmtId(rmElmtId);
        this.__cunzai.purgeDependencyOnElmtId(rmElmtId);
        this.__doctoe_id.purgeDependencyOnElmtId(rmElmtId);
        this.__d_mima.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dname.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        this.__Doctors.aboutToBeDeleted();
        this.__cunzai.aboutToBeDeleted();
        this.__doctoe_id.aboutToBeDeleted();
        this.__d_mima.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dname: ObservedPropertySimplePU<string>;
    get dname() {
        return this.__dname.get();
    }
    set dname(newValue: string) {
        this.__dname.set(newValue);
    }
    private __group_id?: ObservedPropertySimplePU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    private __Doctors: ObservedPropertyObjectPU<DoctorModel[]>;
    get Doctors() {
        return this.__Doctors.get();
    }
    set Doctors(newValue: DoctorModel[]) {
        this.__Doctors.set(newValue);
    }
    private __cunzai: ObservedPropertySimplePU<number>;
    get cunzai() {
        return this.__cunzai.get();
    }
    set cunzai(newValue: number) {
        this.__cunzai.set(newValue);
    }
    private __doctoe_id?: ObservedPropertySimplePU<number>;
    get doctoe_id() {
        return this.__doctoe_id.get();
    }
    set doctoe_id(newValue: number) {
        this.__doctoe_id.set(newValue);
    }
    private __d_mima: ObservedPropertySimplePU<number>;
    get d_mima() {
        return this.__d_mima.get();
    }
    set d_mima(newValue: number) {
        this.__d_mima.set(newValue);
    }
    private findDoctorDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 40 });
            Column.debugLine("entry/src/main/ets/pages/DoctorPage.ets(30:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#ccffcc');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入医生姓名' });
            TextInput.debugLine("entry/src/main/ets/pages/DoctorPage.ets(31:7)", "entry");
            TextInput.onChange((value: string) => {
                this.dname = value;
            });
            TextInput.padding({ top: 50 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入医生密码' });
            TextInput.debugLine("entry/src/main/ets/pages/DoctorPage.ets(37:7)", "entry");
            TextInput.onChange((value: string) => {
                this.d_mima = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.dname);
            Text.debugLine("entry/src/main/ets/pages/DoctorPage.ets(41:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("登陆");
            Button.debugLine("entry/src/main/ets/pages/DoctorPage.ets(42:7)", "entry");
            Button.onClick(() => {
                this.findDoctorDB();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("跳转");
            Button.debugLine("entry/src/main/ets/pages/DoctorPage.ets(47:7)", "entry");
            Button.onClick(() => {
                if (this.cunzai !== -1) {
                    AppStorage.setOrCreate('dname', this.dname);
                    AppStorage.setOrCreate('group_id', this.group_id);
                    AppStorage.setOrCreate('doctor_id', this.doctoe_id);
                    router.pushUrl({
                        url: "pages/DoctorIndex"
                    });
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DoctorPage";
    }
}
registerNamedRoute(() => new DoctorPage(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/DoctorPage", pageFullPath: "entry/src/main/ets/pages/DoctorPage", integratedHsp: "false", moduleType: "followWithHap" });
