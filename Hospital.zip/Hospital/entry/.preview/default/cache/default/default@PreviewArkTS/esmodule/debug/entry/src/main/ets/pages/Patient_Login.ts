if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Patient_Login_Params {
    Username?: string;
    Passwprd?: string;
}
import router from "@ohos:router";
class Patient_Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Username = new ObservedPropertySimplePU("", this, "Username");
        this.__Passwprd = new ObservedPropertySimplePU("", this, "Passwprd");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_Login_Params) {
        if (params.Username !== undefined) {
            this.Username = params.Username;
        }
        if (params.Passwprd !== undefined) {
            this.Passwprd = params.Passwprd;
        }
    }
    updateStateVars(params: Patient_Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Username.purgeDependencyOnElmtId(rmElmtId);
        this.__Passwprd.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Username.aboutToBeDeleted();
        this.__Passwprd.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Username: ObservedPropertySimplePU<string>;
    get Username() {
        return this.__Username.get();
    }
    set Username(newValue: string) {
        this.__Username.set(newValue);
    }
    private __Passwprd: ObservedPropertySimplePU<string>;
    get Passwprd() {
        return this.__Passwprd.get();
    }
    set Passwprd(newValue: string) {
        this.__Passwprd.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/Patient_Login.ets(10:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#C6E2FF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入病人用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_Login.ets(11:7)", "entry");
            TextInput.onChange((value: string) => {
                this.Username = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入病人密码' });
            TextInput.debugLine("entry/src/main/ets/pages/Patient_Login.ets(15:7)", "entry");
            TextInput.onChange((value: string) => {
                this.Passwprd = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 30 });
            Row.debugLine("entry/src/main/ets/pages/Patient_Login.ets(19:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("患者登陆");
            Button.debugLine("entry/src/main/ets/pages/Patient_Login.ets(20:9)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/PatientIndex"
                });
                AppStorage.setOrCreate('Patient_name11', this.Username);
                console.log(`病人姓名为${this.Username}`);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("患者注册");
            Button.debugLine("entry/src/main/ets/pages/Patient_Login.ets(29:9)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Patient"
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Patient_Login";
    }
}
registerNamedRoute(() => new Patient_Login(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Patient_Login", pageFullPath: "entry/src/main/ets/pages/Patient_Login", integratedHsp: "false", moduleType: "followWithHap" });
