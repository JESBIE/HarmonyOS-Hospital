if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PatientPage_Params {
    pname?: string;
    patients?: PatientModel[];
    cunzai?: number;
    findPatientDB?;
}
import type { PatientModel } from '../viewmodel/PatientModel';
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import router from "@ohos:router";
class PatientPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pname = new ObservedPropertySimplePU("", this, "pname");
        this.__patients = new ObservedPropertyObjectPU([], this, "patients");
        this.__cunzai = new ObservedPropertySimplePU(-1, this, "cunzai");
        this.findPatientDB = async () => {
            this.patients = await DButil.query_Patient_DB(['PID', 'NAME', 'AGE', 'GENDER'], 'PATIENTS');
            console.log(`数据库的结果为${JSON.stringify(this.patients)}`);
            let index = this.patients.findIndex((item) => {
                return item.name === this.pname;
            });
            if (index !== -1) {
                console.log("存在该患者信息");
                this.cunzai = index;
            }
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PatientPage_Params) {
        if (params.pname !== undefined) {
            this.pname = params.pname;
        }
        if (params.patients !== undefined) {
            this.patients = params.patients;
        }
        if (params.cunzai !== undefined) {
            this.cunzai = params.cunzai;
        }
        if (params.findPatientDB !== undefined) {
            this.findPatientDB = params.findPatientDB;
        }
    }
    updateStateVars(params: PatientPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pname.purgeDependencyOnElmtId(rmElmtId);
        this.__patients.purgeDependencyOnElmtId(rmElmtId);
        this.__cunzai.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pname.aboutToBeDeleted();
        this.__patients.aboutToBeDeleted();
        this.__cunzai.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pname: ObservedPropertySimplePU<string>;
    get pname() {
        return this.__pname.get();
    }
    set pname(newValue: string) {
        this.__pname.set(newValue);
    }
    private __patients: ObservedPropertyObjectPU<PatientModel[]>;
    get patients() {
        return this.__patients.get();
    }
    set patients(newValue: PatientModel[]) {
        this.__patients.set(newValue);
    }
    private __cunzai: ObservedPropertySimplePU<number>;
    get cunzai() {
        return this.__cunzai.get();
    }
    set cunzai(newValue: number) {
        this.__cunzai.set(newValue);
    }
    private findPatientDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PatientPage.ets(27:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入患者姓名' });
            TextInput.debugLine("entry/src/main/ets/pages/PatientPage.ets(28:7)", "entry");
            TextInput.onChange((value: string) => {
                this.pname = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.cunzai));
            Text.debugLine("entry/src/main/ets/pages/PatientPage.ets(33:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("登陆");
            Button.debugLine("entry/src/main/ets/pages/PatientPage.ets(35:7)", "entry");
            Button.onClick(() => {
                this.findPatientDB();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("跳转");
            Button.debugLine("entry/src/main/ets/pages/PatientPage.ets(40:7)", "entry");
            Button.onClick(() => {
                if (this.cunzai !== -1) {
                    router.pushUrl({
                        url: "pages/Index"
                    });
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PatientPage";
    }
}
registerNamedRoute(() => new PatientPage(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/PatientPage", pageFullPath: "entry/src/main/ets/pages/PatientPage", integratedHsp: "false", moduleType: "followWithHap" });
