export class MissionModel {
    mid?: number;
    id?: number;
    nid?: number;
    group_id?: number;
    mission_text?: string;
}
