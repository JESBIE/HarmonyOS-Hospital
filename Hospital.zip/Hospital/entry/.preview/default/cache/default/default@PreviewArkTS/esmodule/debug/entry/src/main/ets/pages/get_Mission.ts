if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Get_Mission_Params {
    dname?: string;
    group_id?: number;
    Nurses?: NurseModel[];
    findNurseDB?;
}
interface Nurse_view_Params {
    nid?: number;
    name?: string;
    age?: number;
    gender?: string;
    group_id?: number;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { NurseModel } from '../viewmodel/NurseModel';
import router from "@ohos:router";
class Nurse_view extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__nid = new SynchedPropertySimpleOneWayPU(params.nid, this, "nid");
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__gender = new SynchedPropertySimpleOneWayPU(params.gender, this, "gender");
        this.__group_id = new SynchedPropertySimpleOneWayPU(params.group_id, this, "group_id");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Nurse_view_Params) {
    }
    updateStateVars(params: Nurse_view_Params) {
        this.__nid.reset(params.nid);
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__gender.reset(params.gender);
        this.__group_id.reset(params.group_id);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__nid.purgeDependencyOnElmtId(rmElmtId);
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__gender.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__nid.aboutToBeDeleted();
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__gender.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __nid: SynchedPropertySimpleOneWayPU<number>;
    get nid() {
        return this.__nid.get();
    }
    set nid(newValue: number) {
        this.__nid.set(newValue);
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __gender: SynchedPropertySimpleOneWayPU<string>;
    get gender() {
        return this.__gender.get();
    }
    set gender(newValue: string) {
        this.__gender.set(newValue);
    }
    private __group_id: SynchedPropertySimpleOneWayPU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/get_Mission.ets(16:5)", "entry");
            Column.width('90%');
            Column.height(100);
            Column.backgroundColor(Color.Gray);
            Column.borderRadius(4);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.nid));
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(17:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(18:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.age));
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(19:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.gender);
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(20:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.group_id));
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(21:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Get_Mission extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dname = this.createStorageProp('dname', '', "dname");
        this.__group_id = this.createStorageProp('group_id', 0, "group_id");
        this.__Nurses = new ObservedPropertyObjectPU([], this, "Nurses");
        this.findNurseDB = async () => {
            this.Nurses = await DButil.query_Nurse_group(['NID', 'NAME', 'AGE', 'GENDER', 'GROUP_ID'], this.group_id);
            console.log(`数据库的结果为${JSON.stringify(this.Nurses)}`);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Get_Mission_Params) {
        if (params.Nurses !== undefined) {
            this.Nurses = params.Nurses;
        }
        if (params.findNurseDB !== undefined) {
            this.findNurseDB = params.findNurseDB;
        }
    }
    updateStateVars(params: Get_Mission_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dname.purgeDependencyOnElmtId(rmElmtId);
        this.__group_id.purgeDependencyOnElmtId(rmElmtId);
        this.__Nurses.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dname.aboutToBeDeleted();
        this.__group_id.aboutToBeDeleted();
        this.__Nurses.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dname: ObservedPropertyAbstractPU<string>;
    get dname() {
        return this.__dname.get();
    }
    set dname(newValue: string) {
        this.__dname.set(newValue);
    }
    private __group_id: ObservedPropertyAbstractPU<number>;
    get group_id() {
        return this.__group_id.get();
    }
    set group_id(newValue: number) {
        this.__group_id.set(newValue);
    }
    private __Nurses: ObservedPropertyObjectPU<NurseModel[]>;
    get Nurses() {
        return this.__Nurses.get();
    }
    set Nurses(newValue: NurseModel[]) {
        this.__Nurses.set(newValue);
    }
    aboutToAppear(): void {
        this.findNurseDB();
    }
    private findNurseDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/get_Mission.ets(44:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.dname);
            Text.debugLine("entry/src/main/ets/pages/get_Mission.ets(45:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/get_Mission.ets(47:7)", "entry");
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/get_Mission.ets(49:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            __Common__.create();
                            __Common__.onClick(() => {
                                console.log(`点击了${item.name}`);
                                AppStorage.setOrCreate('nid', item.nid);
                                AppStorage.setOrCreate('group_id', item.group_id);
                                router.pushUrl({
                                    url: "pages/get_Mission1"
                                });
                            });
                        }, __Common__);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new Nurse_view(this, { nid: item.nid, name: item.name, age: item.age, gender: item.gender, group_id: item.group_id }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/get_Mission.ets", line: 50, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            nid: item.nid,
                                            name: item.name,
                                            age: item.age,
                                            gender: item.gender,
                                            group_id: item.group_id
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        nid: item.nid, name: item.name, age: item.age, gender: item.gender, group_id: item.group_id
                                    });
                                }
                            }, { name: "Nurse_view" });
                        }
                        __Common__.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.Nurses, forEachItemGenFunction, (item: NurseModel) => JSON.stringify(item.nid), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Get_Mission";
    }
}
registerNamedRoute(() => new Get_Mission(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_Mission", pageFullPath: "entry/src/main/ets/pages/get_Mission", integratedHsp: "false", moduleType: "followWithHap" });
