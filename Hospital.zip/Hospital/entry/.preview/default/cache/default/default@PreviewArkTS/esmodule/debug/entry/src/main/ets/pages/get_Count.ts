if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Patient_count_Params {
    data1?: number[];
    data2?: number[];
    defOptions?: Options;
    defOptions1?: Options;
}
import { McLineChart, Options } from "@normalized:N&&&@mcui/mccharts/index&2.8.4";
class Patient_count extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__data1 = new ObservedPropertyObjectPU([], this, "data1");
        this.__data2 = this.createStorageProp('week', [], "data2");
        this.__defOptions = new ObservedPropertyObjectPU(new Options({
            xAxis: {
                data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
            },
            yAxis: {
                name: '患者人数'
            },
            series: [
                {
                    name: "每日预约人数",
                    data: this.data2
                }
            ]
        }), this, "defOptions");
        this.__defOptions1 = new ObservedPropertyObjectPU(new Options({
            color: ['#FAAD14', '#3C73FF', '#52C41A', '#FF4D4F'],
            legend: {
                top: '5%',
                itemWidth: 10,
                itemHeight: 10,
                textStyle: {
                    color: '#ff00b4ff',
                    fontSize: 30,
                    fontWeight: '800'
                }
            },
            series: [
                {
                    center: ['50%', '30%'],
                    data: [
                        { name: 'MON', value: this.data2[0] },
                        { name: 'TUE', value: this.data2[1] },
                        { name: 'WEN', value: this.data2[2] },
                        { name: 'THU', value: this.data2[3] },
                        { name: 'FRI', value: this.data2[4] },
                        { name: 'SAT', value: this.data2[5] },
                        { name: 'SUN', value: this.data2[6] },
                    ],
                    labelLine: {
                        length: 10,
                        length2: 30,
                        lineStyle: {
                            width: 1,
                            color: '#ffff0000'
                        }
                    },
                    label: {
                        show: true,
                        fontWeight: '800',
                        fontFamily: 'sans-serif',
                        color: '#ffffffff',
                        position: 'outside',
                        fontSize: 30,
                        distanceToLabelLine: 6
                    },
                }
            ],
            tooltip: {
                axisPointer: {
                    type: 'line',
                    lineStyle: {
                        color: '#D9D9D9',
                        width: 2,
                        type: 'solid'
                    }
                },
                backgroundColor: '#FFFFFF',
                borderColor: '#C4C4C4',
                borderWidth: 1,
                padding: 6,
                textStyle: {
                    color: '#666666',
                    fontSize: 14
                }
            },
        }), this, "defOptions1");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_count_Params) {
        if (params.data1 !== undefined) {
            this.data1 = params.data1;
        }
        if (params.defOptions !== undefined) {
            this.defOptions = params.defOptions;
        }
        if (params.defOptions1 !== undefined) {
            this.defOptions1 = params.defOptions1;
        }
    }
    updateStateVars(params: Patient_count_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__data1.purgeDependencyOnElmtId(rmElmtId);
        this.__data2.purgeDependencyOnElmtId(rmElmtId);
        this.__defOptions.purgeDependencyOnElmtId(rmElmtId);
        this.__defOptions1.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__data1.aboutToBeDeleted();
        this.__data2.aboutToBeDeleted();
        this.__defOptions.aboutToBeDeleted();
        this.__defOptions1.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __data1: ObservedPropertyObjectPU<number[]>;
    get data1() {
        return this.__data1.get();
    }
    set data1(newValue: number[]) {
        this.__data1.set(newValue);
    }
    private __data2: ObservedPropertyAbstractPU<number[]>;
    get data2() {
        return this.__data2.get();
    }
    set data2(newValue: number[]) {
        this.__data2.set(newValue);
    }
    private __defOptions: ObservedPropertyObjectPU<Options>;
    get defOptions() {
        return this.__defOptions.get();
    }
    set defOptions(newValue: Options) {
        this.__defOptions.set(newValue);
    }
    private __defOptions1: ObservedPropertyObjectPU<Options>;
    get defOptions1() {
        return this.__defOptions1.get();
    }
    set defOptions1(newValue: Options) {
        this.__defOptions1.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/get_Count.ets(87:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.height('50%');
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new McLineChart(this, { options: this.defOptions }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/get_Count.ets", line: 88, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            options: this.defOptions
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        options: this.defOptions
                    });
                }
            }, { name: "McLineChart" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.height('50%');
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new McLineChart(this, { options: this.defOptions1 }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/get_Count.ets", line: 89, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            options: this.defOptions1
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        options: this.defOptions1
                    });
                }
            }, { name: "McLineChart" });
        }
        __Common__.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Patient_count";
    }
}
registerNamedRoute(() => new Patient_count(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_Count", pageFullPath: "entry/src/main/ets/pages/get_Count", integratedHsp: "false", moduleType: "followWithHap" });
