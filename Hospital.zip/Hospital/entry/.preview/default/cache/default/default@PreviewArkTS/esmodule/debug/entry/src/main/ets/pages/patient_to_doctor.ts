if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Patient_to_doctor_Params {
    pid?: number;
    Diagnose?: DiagnoseModel[];
    Doctor?: DoctorModel[];
    findDoctor?;
}
interface Doctor_view_Params {
    name?: string;
    age?: number;
    level?: string;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DiagnoseModel } from '../viewmodel/DiagnoseModel';
import type { DoctorModel } from '../viewmodel/DoctorModel';
class Doctor_view extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__level = new SynchedPropertySimpleOneWayPU(params.level, this, "level");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Doctor_view_Params) {
    }
    updateStateVars(params: Doctor_view_Params) {
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__level.reset(params.level);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__level.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__level.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __level: SynchedPropertySimpleOneWayPU<string>;
    get level() {
        return this.__level.get();
    }
    set level(newValue: string) {
        this.__level.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(11:5)", "entry");
            Column.width('90%');
            Column.height(60);
            Column.backgroundColor(Color.Gray);
            Column.borderRadius(4);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(12:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.age));
            Text.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(13:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.level);
            Text.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(14:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Patient_to_doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__pid = new ObservedPropertySimplePU(0, this, "pid");
        this.__Diagnose = new ObservedPropertyObjectPU([], this, "Diagnose");
        this.__Doctor = new ObservedPropertyObjectPU([], this, "Doctor");
        this.findDoctor = async () => {
            this.Diagnose = await DButil.query_diagnoses(['DIAGNOSE_ID', 'ID', 'PID'], 'DIAGNOSES', this.pid);
            let len = this.Diagnose.length;
            console.log(`数据库的结果为${JSON.stringify(this.Diagnose)}`);
            for (let i = 0; i < len; i++) {
                console.log("执行");
                console.log(`医生编号为${this.Diagnose[i].id}`);
                const id: number = this.Diagnose[i].id;
                const Doctori = await DButil.queryDoctor(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], 'Doctor', id);
                console.log(`查询到的医生信息${JSON.stringify(Doctori)}`);
                this.Doctor.push(Doctori);
            }
            console.log(`患者预约的医生信息如下${JSON.stringify(this.Doctor)}`);
            console.log("执行完毕");
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_to_doctor_Params) {
        if (params.pid !== undefined) {
            this.pid = params.pid;
        }
        if (params.Diagnose !== undefined) {
            this.Diagnose = params.Diagnose;
        }
        if (params.Doctor !== undefined) {
            this.Doctor = params.Doctor;
        }
        if (params.findDoctor !== undefined) {
            this.findDoctor = params.findDoctor;
        }
    }
    updateStateVars(params: Patient_to_doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__pid.purgeDependencyOnElmtId(rmElmtId);
        this.__Diagnose.purgeDependencyOnElmtId(rmElmtId);
        this.__Doctor.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__pid.aboutToBeDeleted();
        this.__Diagnose.aboutToBeDeleted();
        this.__Doctor.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __pid: ObservedPropertySimplePU<number>;
    get pid() {
        return this.__pid.get();
    }
    set pid(newValue: number) {
        this.__pid.set(newValue);
    }
    private __Diagnose: ObservedPropertyObjectPU<DiagnoseModel[]>;
    get Diagnose() {
        return this.__Diagnose.get();
    }
    set Diagnose(newValue: DiagnoseModel[]) {
        this.__Diagnose.set(newValue);
    }
    private __Doctor: ObservedPropertyObjectPU<DoctorModel[]>;
    get Doctor() {
        return this.__Doctor.get();
    }
    set Doctor(newValue: DoctorModel[]) {
        this.__Doctor.set(newValue);
    }
    private findDoctor;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(50:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入患者编号' });
            TextInput.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(51:7)", "entry");
            TextInput.onChange((value: string) => {
                this.pid = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认查询");
            Button.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(56:7)", "entry");
            Button.onClick(this.findDoctor);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(58:7)", "entry");
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/patient_to_doctor.ets(60:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new Doctor_view(this, { name: item.name, age: item.age, level: item.level }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/patient_to_doctor.ets", line: 61, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            name: item.name,
                                            age: item.age,
                                            level: item.level
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        name: item.name, age: item.age, level: item.level
                                    });
                                }
                            }, { name: "Doctor_view" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.Doctor, forEachItemGenFunction, (item: DoctorModel) => JSON.stringify(item.id), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Patient_to_doctor";
    }
}
registerNamedRoute(() => new Patient_to_doctor(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/patient_to_doctor", pageFullPath: "entry/src/main/ets/pages/patient_to_doctor", integratedHsp: "false", moduleType: "followWithHap" });
