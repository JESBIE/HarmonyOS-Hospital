if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PatientIndex_Params {
    Patient_name?: string;
    patient_id?: number;
    find_patient_id?;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import router from "@ohos:router";
class PatientIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Patient_name = this.createStorageProp('Patient_name11', "", "Patient_name");
        this.__patient_id = new ObservedPropertySimplePU(0, this, "patient_id");
        this.find_patient_id = async () => {
            this.patient_id = await DButil.query_patient_id(this.Patient_name);
            console.log(`患者的ID为${this.patient_id}`);
            console.log(`患者姓名为${this.Patient_name}`);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PatientIndex_Params) {
        if (params.patient_id !== undefined) {
            this.patient_id = params.patient_id;
        }
        if (params.find_patient_id !== undefined) {
            this.find_patient_id = params.find_patient_id;
        }
    }
    updateStateVars(params: PatientIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Patient_name.purgeDependencyOnElmtId(rmElmtId);
        this.__patient_id.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Patient_name.aboutToBeDeleted();
        this.__patient_id.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Patient_name: ObservedPropertyAbstractPU<string>;
    get Patient_name() {
        return this.__Patient_name.get();
    }
    set Patient_name(newValue: string) {
        this.__Patient_name.set(newValue);
    }
    private __patient_id: ObservedPropertySimplePU<number>;
    get patient_id() {
        return this.__patient_id.get();
    }
    set patient_id(newValue: number) {
        this.__patient_id.set(newValue);
    }
    aboutToAppear(): void {
        console.log("进入病人页面");
        console.log(`患者姓名为${this.Patient_name}`);
        this.find_patient_id();
    }
    private find_patient_id;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(25:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#C6E2FF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`欢迎${this.Patient_name}!`);
            Text.debugLine("entry/src/main/ets/pages/PatientIndex.ets(26:5)", "entry");
            Text.padding({ top: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(30:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 40 });
            Row.debugLine("entry/src/main/ets/pages/PatientIndex.ets(31:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(32:11)", "entry");
            Column.backgroundColor('#EEA9B8');
            Column.height(120);
            Column.width(120);
            Column.borderRadius(15);
            Column.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Patient"
                });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777241, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PatientIndex.ets(33:13)", "entry");
            Image.width(70);
            Image.height(70);
            Image.padding({ top: 5 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("添加病人");
            Text.debugLine("entry/src/main/ets/pages/PatientIndex.ets(37:13)", "entry");
            Text.fontStyle(FontStyle.Italic);
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(51:11)", "entry");
            Column.backgroundColor('#99ffcc');
            Column.height(120);
            Column.width(120);
            Column.borderRadius(15);
            Column.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Diagnoses"
                });
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PatientIndex.ets(52:13)", "entry");
            Image.width(70);
            Image.height(70);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("添加预约");
            Text.debugLine("entry/src/main/ets/pages/PatientIndex.ets(55:13)", "entry");
            Text.fontStyle(FontStyle.Italic);
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 40 });
            Row.debugLine("entry/src/main/ets/pages/PatientIndex.ets(72:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(73:9)", "entry");
            Column.onClick(() => {
                router.pushUrl({
                    url: "pages/patient_to_doctor"
                });
            });
            Column.backgroundColor('#E0FFFF');
            Column.height(130);
            Column.width(130);
            Column.borderRadius(15);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777243, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PatientIndex.ets(74:11)", "entry");
            Image.height(70);
            Image.padding({ top: 10 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("预约查询");
            Text.debugLine("entry/src/main/ets/pages/PatientIndex.ets(77:11)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/PatientIndex.ets(90:9)", "entry");
            Column.onClick(() => {
                router.pushUrl({
                    url: "pages/update_Patient"
                });
            });
            Column.backgroundColor('#FFF8DC');
            Column.height(130);
            Column.width(130);
            Column.borderRadius(15);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/PatientIndex.ets(91:11)", "entry");
            Image.height(70);
            Image.padding({ top: 10 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("更改用户");
            Text.debugLine("entry/src/main/ets/pages/PatientIndex.ets(94:11)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PatientIndex";
    }
}
registerNamedRoute(() => new PatientIndex(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/PatientIndex", pageFullPath: "entry/src/main/ets/pages/PatientIndex", integratedHsp: "false", moduleType: "followWithHap" });
