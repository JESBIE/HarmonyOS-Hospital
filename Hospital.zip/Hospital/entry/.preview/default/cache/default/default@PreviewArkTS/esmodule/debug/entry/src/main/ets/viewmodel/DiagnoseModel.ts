export class DiagnoseModel {
    diagnose_id?: number;
    id: number = 0;
    pid: number = 0;
}
