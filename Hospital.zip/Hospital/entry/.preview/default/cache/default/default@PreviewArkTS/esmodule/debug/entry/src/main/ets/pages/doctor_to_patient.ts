if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Doctor_to_patient_Params {
    Diagnose?: DiagnoseModel[];
    Patient?: PatientModel[];
    did1?: number;
    name_Picked?: string;
    dialogController?: CustomDialogController | null;
    findPatient?;
}
interface Patient_view_Params {
    name?: string;
    age?: number;
    gender?: string;
}
interface CustomDialogExample_Params {
    controller?: CustomDialogController;
    name?: string;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DiagnoseModel } from '../viewmodel/DiagnoseModel';
import type { PatientModel } from '../viewmodel/PatientModel';
import router from "@ohos:router";
class CustomDialogExample extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CustomDialogExample_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.name === undefined) {
            this.__name.set("");
        }
    }
    updateStateVars(params: CustomDialogExample_Params) {
        this.__name.reset(params.name);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller?: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(13:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Whether to change a text?');
            Text.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(14:7)", "entry");
            Text.fontSize(16);
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(19:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("删除");
            Button.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(20:9)", "entry");
            Button.onClick(() => {
                this.controller?.close();
                console.log(`弹窗内得到的${this.name}`);
                DButil.deleteDB_name('PATIENTS', this.name);
                router.pushUrl({
                    url: "pages/DoctorIndex"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("取消");
            Button.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(29:9)", "entry");
            Button.onClick(() => {
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Patient_view extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__gender = new SynchedPropertySimpleOneWayPU(params.gender, this, "gender");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Patient_view_Params) {
    }
    updateStateVars(params: Patient_view_Params) {
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__gender.reset(params.gender);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__gender.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__gender.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __gender: SynchedPropertySimpleOneWayPU<string>;
    get gender() {
        return this.__gender.get();
    }
    set gender(newValue: string) {
        this.__gender.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(45:5)", "entry");
            Column.width('90%');
            Column.height(60);
            Column.backgroundColor(Color.Gray);
            Column.borderRadius(4);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(46:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.age));
            Text.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(47:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.gender);
            Text.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(48:7)", "entry");
        }, Text);
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Doctor_to_patient extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Diagnose = new ObservedPropertyObjectPU([], this, "Diagnose");
        this.__Patient = new ObservedPropertyObjectPU([], this, "Patient");
        this.__did1 = this.createStorageProp('did1', 1, "did1");
        this.__name_Picked = new ObservedPropertySimplePU("", this, "name_Picked");
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomDialogExample(this, { name: this.name_Picked }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/doctor_to_patient.ets", line: 66, col: 14 });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        name: this.name_Picked
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            openAnimation: {
                duration: 1200,
                curve: Curve.Friction,
                delay: 500,
                playMode: PlayMode.Alternate,
                onFinish: () => {
                    console.info('play end');
                }
            },
            autoCancel: true,
            alignment: DialogAlignment.Bottom,
            offset: { dx: 0, dy: -20 },
            gridCount: 4,
            customStyle: false,
            backgroundColor: 0xd9ffffff,
            cornerRadius: 10
        }, this);
        this.findPatient = async () => {
            this.Diagnose = await DButil.query_Dr_patient(['DIAGNOSE_ID', 'ID', 'PID'], 'DIAGNOSES', this.did1);
            let len = this.Diagnose.length;
            console.log(`医患预约的结果为${JSON.stringify(this.Diagnose)}`);
            for (let i = 0; i < len; i++) {
                console.log("执行");
                console.log(`患者编号为${this.Diagnose[i].pid}`);
                const pid: number = this.Diagnose[i].pid;
                const Patienti = await DButil.query_Patient_DB(['PID', 'NAME', 'AGE', 'GENDER'], 'PATIENTS', pid);
                console.log(`查询到的患者信息${JSON.stringify(Patienti)}`);
                this.Patient.push(Patienti[0]);
            }
            console.log(`医生还需要诊断的预约患者${JSON.stringify(this.Patient)}`);
            console.log("执行完毕");
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Doctor_to_patient_Params) {
        if (params.Diagnose !== undefined) {
            this.Diagnose = params.Diagnose;
        }
        if (params.Patient !== undefined) {
            this.Patient = params.Patient;
        }
        if (params.name_Picked !== undefined) {
            this.name_Picked = params.name_Picked;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
        if (params.findPatient !== undefined) {
            this.findPatient = params.findPatient;
        }
    }
    updateStateVars(params: Doctor_to_patient_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Diagnose.purgeDependencyOnElmtId(rmElmtId);
        this.__Patient.purgeDependencyOnElmtId(rmElmtId);
        this.__did1.purgeDependencyOnElmtId(rmElmtId);
        this.__name_Picked.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Diagnose.aboutToBeDeleted();
        this.__Patient.aboutToBeDeleted();
        this.__did1.aboutToBeDeleted();
        this.__name_Picked.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Diagnose: ObservedPropertyObjectPU<DiagnoseModel[]>;
    get Diagnose() {
        return this.__Diagnose.get();
    }
    set Diagnose(newValue: DiagnoseModel[]) {
        this.__Diagnose.set(newValue);
    }
    private __Patient: ObservedPropertyObjectPU<PatientModel[]>;
    get Patient() {
        return this.__Patient.get();
    }
    set Patient(newValue: PatientModel[]) {
        this.__Patient.set(newValue);
    }
    private __did1: ObservedPropertyAbstractPU<number>;
    get did1() {
        return this.__did1.get();
    }
    set did1(newValue: number) {
        this.__did1.set(newValue);
    }
    private __name_Picked?: ObservedPropertySimplePU<string>;
    get name_Picked() {
        return this.__name_Picked.get();
    }
    set name_Picked(newValue: string) {
        this.__name_Picked.set(newValue);
    }
    private dialogController: CustomDialogController | null;
    aboutToAppear(): void {
        this.findPatient();
        console.log(`医生的编号为${this.did1}`);
    }
    private findPatient;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(115:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // TextInput({placeholder:'请输入医生编号'})
            //   .onChange((value:string)=>{
            //     this.did=Number(value)
            //   })
            //
            // Button("确认查询").onClick(this.findPatient)
            List.create({ space: 15 });
            List.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(123:7)", "entry");
            // TextInput({placeholder:'请输入医生编号'})
            //   .onChange((value:string)=>{
            //     this.did=Number(value)
            //   })
            //
            // Button("确认查询").onClick(this.findPatient)
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/doctor_to_patient.ets(125:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            __Common__.create();
                            __Common__.onClick(() => {
                                console.log(`点击了${item.name}`);
                                this.name_Picked = item.name;
                                if (this.dialogController != null) {
                                    this.dialogController.open();
                                }
                            });
                        }, __Common__);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new Patient_view(this, { name: item.name, age: item.age, gender: item.gender }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/doctor_to_patient.ets", line: 126, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            name: item.name,
                                            age: item.age,
                                            gender: item.gender
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {
                                        name: item.name, age: item.age, gender: item.gender
                                    });
                                }
                            }, { name: "Patient_view" });
                        }
                        __Common__.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.Patient, forEachItemGenFunction, (item: PatientModel) => JSON.stringify(item.pid), false, false);
        }, ForEach);
        ForEach.pop();
        // TextInput({placeholder:'请输入医生编号'})
        //   .onChange((value:string)=>{
        //     this.did=Number(value)
        //   })
        //
        // Button("确认查询").onClick(this.findPatient)
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Doctor_to_patient";
    }
}
registerNamedRoute(() => new Doctor_to_patient(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/doctor_to_patient", pageFullPath: "entry/src/main/ets/pages/doctor_to_patient", integratedHsp: "false", moduleType: "followWithHap" });
