if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Get_User_Params {
    username?: string;
    password?: string;
    gotoLogin?;
    add_user?;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type relationalStore from "@ohos:data.relationalStore";
import router from "@ohos:router";
class Get_User extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU("", this, "username");
        this.__password = new ObservedPropertySimplePU("", this, "password");
        this.gotoLogin = () => {
            router.pushUrl({
                url: "pages/Login_Page"
            });
        };
        this.add_user = () => {
            console.log("添加用户");
            const valueBucket: relationalStore.ValuesBucket = {
                'USERNAME': this.username,
                'PASSWORD': this.password
            };
            console.log(`已经添加用户${JSON.stringify(valueBucket)}`);
            DButil.insertDB('USERS', valueBucket);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Get_User_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.gotoLogin !== undefined) {
            this.gotoLogin = params.gotoLogin;
        }
        if (params.add_user !== undefined) {
            this.add_user = params.add_user;
        }
    }
    updateStateVars(params: Get_User_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private gotoLogin;
    private add_user;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 25 });
            Column.debugLine("entry/src/main/ets/pages/get_User.ets(25:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#B4CDCD');
            Column.padding({ top: 40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入注册用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/get_User.ets(26:7)", "entry");
            TextInput.onChange((value: string) => {
                this.username = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入注册密码' });
            TextInput.debugLine("entry/src/main/ets/pages/get_User.ets(33:7)", "entry");
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认添加用户");
            Button.debugLine("entry/src/main/ets/pages/get_User.ets(38:7)", "entry");
            Button.onClick(this.add_user);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Get_User";
    }
}
registerNamedRoute(() => new Get_User(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/get_User", pageFullPath: "entry/src/main/ets/pages/get_User", integratedHsp: "false", moduleType: "followWithHap" });
