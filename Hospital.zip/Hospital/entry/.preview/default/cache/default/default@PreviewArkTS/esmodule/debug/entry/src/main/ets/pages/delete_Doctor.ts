if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Delete_Doctor_Params {
    did?: number;
    deleteDoctor?;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
class Delete_Doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__did = new ObservedPropertySimplePU(0, this, "did");
        this.deleteDoctor = () => {
            DButil.deleteDB('Doctor', this.did);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Delete_Doctor_Params) {
        if (params.did !== undefined) {
            this.did = params.did;
        }
        if (params.deleteDoctor !== undefined) {
            this.deleteDoctor = params.deleteDoctor;
        }
    }
    updateStateVars(params: Delete_Doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__did.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__did.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __did: ObservedPropertySimplePU<number>;
    get did() {
        return this.__did.get();
    }
    set did(newValue: number) {
        this.__did.set(newValue);
    }
    private deleteDoctor;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/delete_Doctor.ets(15:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入医生编号' });
            TextInput.debugLine("entry/src/main/ets/pages/delete_Doctor.ets(17:7)", "entry");
            TextInput.onChange((value: string) => {
                this.did = Number(value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确认删除");
            Button.debugLine("entry/src/main/ets/pages/delete_Doctor.ets(21:7)", "entry");
            Button.onClick(this.deleteDoctor);
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Delete_Doctor";
    }
}
registerNamedRoute(() => new Delete_Doctor(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/delete_Doctor", pageFullPath: "entry/src/main/ets/pages/delete_Doctor", integratedHsp: "false", moduleType: "followWithHap" });
