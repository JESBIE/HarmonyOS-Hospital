if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DoctorIndex_Params {
    dname?: string;
    did?: number;
    doctor_id?: number;
    doctor1?: DoctorModel;
    logs?: MissionLogModel[];
    missions?: MissionModel[];
    find_Doctor?;
    find_Mission?;
    find_logs?;
    textValue?: string;
    inputValue?: string;
    dialogController?: CustomDialogController | null;
}
interface See_Doctor_Params {
}
interface Set_Mission_Params {
}
interface Check_patient_Params {
}
interface CustomDialogExample_Params {
    controller?: CustomDialogController;
    name?: string;
    age?: number;
    salary?: number;
    level?: string;
}
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import { DoctorModel } from "@normalized:N&&&entry/src/main/ets/viewmodel/DoctorModel&";
import router from "@ohos:router";
import type { MissionLogModel } from '../viewmodel/MissionLogModel';
import type { MissionModel } from '../viewmodel/MissionModel';
class CustomDialogExample extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.__name = new SynchedPropertySimpleOneWayPU(params.name, this, "name");
        this.__age = new SynchedPropertySimpleOneWayPU(params.age, this, "age");
        this.__salary = new SynchedPropertySimpleOneWayPU(params.salary, this, "salary");
        this.__level = new SynchedPropertySimpleOneWayPU(params.level, this, "level");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CustomDialogExample_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.name === undefined) {
            this.__name.set("");
        }
        if (params.age === undefined) {
            this.__age.set(0);
        }
        if (params.salary === undefined) {
            this.__salary.set(0);
        }
        if (params.level === undefined) {
            this.__level.set("");
        }
    }
    updateStateVars(params: CustomDialogExample_Params) {
        this.__name.reset(params.name);
        this.__age.reset(params.age);
        this.__salary.reset(params.salary);
        this.__level.reset(params.level);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__name.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
        this.__salary.purgeDependencyOnElmtId(rmElmtId);
        this.__level.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__name.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        this.__salary.aboutToBeDeleted();
        this.__level.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller?: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private __name: SynchedPropertySimpleOneWayPU<string>;
    get name() {
        return this.__name.get();
    }
    set name(newValue: string) {
        this.__name.set(newValue);
    }
    private __age: SynchedPropertySimpleOneWayPU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    private __salary: SynchedPropertySimpleOneWayPU<number>;
    get salary() {
        return this.__salary.get();
    }
    set salary(newValue: number) {
        this.__salary.set(newValue);
    }
    private __level: SynchedPropertySimpleOneWayPU<string>;
    get level() {
        return this.__level.get();
    }
    set level(newValue: string) {
        this.__level.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(16:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('信息查看');
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(17:7)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.name);
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(20:7)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.age));
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(23:7)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(JSON.stringify(this.salary));
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(26:7)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.level);
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(29:7)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("确定");
            Button.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(31:9)", "entry");
            Button.onClick(() => {
                this.controller?.close();
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Check_patient extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Check_patient_Params) {
    }
    updateStateVars(params: Check_patient_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 30 });
            Row.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(42:5)", "entry");
            Row.height(45);
            Row.backgroundColor('#EED2EE');
            Row.width(300);
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(43:7)", "entry");
            Image.height(30);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("查看预约患者");
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(47:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Set_Mission extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Set_Mission_Params) {
    }
    updateStateVars(params: Set_Mission_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 24 });
            Row.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(63:5)", "entry");
            Row.height(45);
            Row.backgroundColor('#EED2EE');
            Row.width(300);
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(64:7)", "entry");
            Image.height(40);
            Image.width(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("护士任务下发");
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(68:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class See_Doctor extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: See_Doctor_Params) {
    }
    updateStateVars(params: See_Doctor_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 24 });
            Row.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(83:5)", "entry");
            Row.height(45);
            Row.backgroundColor('#EED2EE');
            Row.width(300);
            Row.justifyContent(FlexAlign.Center);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(84:7)", "entry");
            Image.height(40);
            Image.width(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("查看医生信息");
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(88:7)", "entry");
            Text.fontSize(25);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class DoctorIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dname = this.createStorageProp('dname', '', "dname");
        this.__did = this.createStorageProp('group_id', 0, "did");
        this.__doctor_id = this.createStorageProp('id', 0, "doctor_id");
        this.__doctor1 = new ObservedPropertyObjectPU(new DoctorModel(), this, "doctor1");
        this.__logs = new ObservedPropertyObjectPU([], this, "logs");
        this.__missions = new ObservedPropertyObjectPU([], this, "missions");
        this.find_Doctor = async () => {
            this.doctor1 = await DButil.query_Doctor_name(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], this.dname);
            console.log(`医生信息${JSON.stringify(this.doctor1)}`);
        };
        this.find_Mission = async () => {
            this.missions = await DButil.query_Mission(['MID', 'MISSION_TEXT']);
            console.log(`任务信息${JSON.stringify(this.missions)}`);
        };
        this.find_logs = async () => {
            this.logs = await DButil.query_Mission_log(['LOG_ID', 'LOG_TIME', 'DETAILS']);
            console.log(`日志信息${JSON.stringify(this.logs)}`);
        };
        this.__textValue = new ObservedPropertySimplePU('', this, "textValue");
        this.__inputValue = new ObservedPropertySimplePU('click me', this, "inputValue");
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomDialogExample(this, { name: this.doctor1.name, age: this.doctor1.age, salary: this.doctor1.salary, level: this.doctor1.level }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/DoctorIndex.ets", line: 140, col: 14 });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        name: this.doctor1.name,
                        age: this.doctor1.age,
                        salary: this.doctor1.salary,
                        level: this.doctor1.level
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            openAnimation: {
                duration: 1200,
                curve: Curve.Friction,
                delay: 500,
                playMode: PlayMode.Alternate,
                onFinish: () => {
                    console.info('play end');
                }
            },
            autoCancel: true,
            alignment: DialogAlignment.Bottom,
            offset: { dx: 0, dy: -20 },
            gridCount: 4,
            customStyle: false,
            backgroundColor: 0xd9ffffff,
            cornerRadius: 10
        }, this);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DoctorIndex_Params) {
        if (params.doctor1 !== undefined) {
            this.doctor1 = params.doctor1;
        }
        if (params.logs !== undefined) {
            this.logs = params.logs;
        }
        if (params.missions !== undefined) {
            this.missions = params.missions;
        }
        if (params.find_Doctor !== undefined) {
            this.find_Doctor = params.find_Doctor;
        }
        if (params.find_Mission !== undefined) {
            this.find_Mission = params.find_Mission;
        }
        if (params.find_logs !== undefined) {
            this.find_logs = params.find_logs;
        }
        if (params.textValue !== undefined) {
            this.textValue = params.textValue;
        }
        if (params.inputValue !== undefined) {
            this.inputValue = params.inputValue;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params: DoctorIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dname.purgeDependencyOnElmtId(rmElmtId);
        this.__did.purgeDependencyOnElmtId(rmElmtId);
        this.__doctor_id.purgeDependencyOnElmtId(rmElmtId);
        this.__doctor1.purgeDependencyOnElmtId(rmElmtId);
        this.__logs.purgeDependencyOnElmtId(rmElmtId);
        this.__missions.purgeDependencyOnElmtId(rmElmtId);
        this.__textValue.purgeDependencyOnElmtId(rmElmtId);
        this.__inputValue.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dname.aboutToBeDeleted();
        this.__did.aboutToBeDeleted();
        this.__doctor_id.aboutToBeDeleted();
        this.__doctor1.aboutToBeDeleted();
        this.__logs.aboutToBeDeleted();
        this.__missions.aboutToBeDeleted();
        this.__textValue.aboutToBeDeleted();
        this.__inputValue.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dname: ObservedPropertyAbstractPU<string>;
    get dname() {
        return this.__dname.get();
    }
    set dname(newValue: string) {
        this.__dname.set(newValue);
    }
    private __did: ObservedPropertyAbstractPU<number>;
    get did() {
        return this.__did.get();
    }
    set did(newValue: number) {
        this.__did.set(newValue);
    }
    private __doctor_id: ObservedPropertyAbstractPU<number>;
    get doctor_id() {
        return this.__doctor_id.get();
    }
    set doctor_id(newValue: number) {
        this.__doctor_id.set(newValue);
    }
    private __doctor1: ObservedPropertyObjectPU<DoctorModel>;
    get doctor1() {
        return this.__doctor1.get();
    }
    set doctor1(newValue: DoctorModel) {
        this.__doctor1.set(newValue);
    }
    private __logs: ObservedPropertyObjectPU<MissionLogModel[]>;
    get logs() {
        return this.__logs.get();
    }
    set logs(newValue: MissionLogModel[]) {
        this.__logs.set(newValue);
    }
    private __missions: ObservedPropertyObjectPU<MissionModel[]>;
    get missions() {
        return this.__missions.get();
    }
    set missions(newValue: MissionModel[]) {
        this.__missions.set(newValue);
    }
    aboutToAppear(): void {
        console.log('开始加载');
        this.find_Doctor();
        this.find_logs();
        this.find_Mission();
    }
    private find_Doctor;
    private find_Mission;
    private find_logs;
    private __textValue: ObservedPropertySimplePU<string>;
    get textValue() {
        return this.__textValue.get();
    }
    set textValue(newValue: string) {
        this.__textValue.set(newValue);
    }
    private __inputValue: ObservedPropertySimplePU<string>;
    get inputValue() {
        return this.__inputValue.get();
    }
    set inputValue(newValue: string) {
        this.__inputValue.set(newValue);
    }
    private dialogController: CustomDialogController | null;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(159:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.backgroundColor('#FAF0E6');
            Column.padding({ top: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`欢迎${this.dname}医生`);
            Text.debugLine("entry/src/main/ets/pages/DoctorIndex.ets(160:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                console.log(`建立的临时变量的did为${this.did}`);
                AppStorage.setOrCreate('did1', this.doctor_id);
                router.pushUrl({
                    url: "pages/doctor_to_patient"
                });
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Check_patient(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DoctorIndex.ets", line: 161, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Check_patient" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                if (this.dialogController != null) {
                    this.dialogController.open();
                }
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    //
                    See_Doctor(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DoctorIndex.ets", line: 170, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "See_Doctor" });
        }
        __Common__.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            __Common__.create();
            __Common__.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Mission"
                });
            });
        }, __Common__);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Set_Mission(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DoctorIndex.ets", line: 176, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Set_Mission" });
        }
        __Common__.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DoctorIndex";
    }
}
registerNamedRoute(() => new DoctorIndex(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/DoctorIndex", pageFullPath: "entry/src/main/ets/pages/DoctorIndex", integratedHsp: "false", moduleType: "followWithHap" });
