if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    Doctors?: DoctorModel[];
    addDoctor?;
    deleteDoctor?;
    findDoctorDB?;
}
import type relationalStore from "@ohos:data.relationalStore";
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DoctorModel } from '../viewmodel/DoctorModel';
import router from "@ohos:router";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Doctors = new ObservedPropertyObjectPU([], this, "Doctors");
        this.addDoctor = () => {
            const valueBucket: relationalStore.ValuesBucket = {
                'NAME': "往佳节",
                'AGE': 12,
                'SALARY': 200,
                'LEVEL': "11",
                'GROUP_ID': 1
            };
            DButil.insertDB('Doctor', valueBucket);
        };
        this.deleteDoctor = () => {
            DButil.deleteDB('Doctor', 1);
        };
        this.findDoctorDB = async () => {
            this.Doctors = await DButil.queryDB(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], 'Doctor');
            console.log(`数据库的结果为${JSON.stringify(this.Doctors)}`);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.Doctors !== undefined) {
            this.Doctors = params.Doctors;
        }
        if (params.addDoctor !== undefined) {
            this.addDoctor = params.addDoctor;
        }
        if (params.deleteDoctor !== undefined) {
            this.deleteDoctor = params.deleteDoctor;
        }
        if (params.findDoctorDB !== undefined) {
            this.findDoctorDB = params.findDoctorDB;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Doctors.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Doctors.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Doctors: ObservedPropertyObjectPU<DoctorModel[]>;
    get Doctors() {
        return this.__Doctors.get();
    }
    set Doctors(newValue: DoctorModel[]) {
        this.__Doctors.set(newValue);
    }
    private addDoctor;
    private deleteDoctor;
    aboutToAppear(): void {
        this.findDoctorDB();
    }
    private findDoctorDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(37:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("添加医生信息");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(38:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Doctor"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("删除医生信息");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(44:7)", "entry");
            Button.onClick(this.deleteDoctor);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("查询数据库");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(45:7)", "entry");
            Button.onClick(this.findDoctorDB);
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/Doctor"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("跳转登陆页面");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(51:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/Login_Page"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("跳转注册页面");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(56:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_User"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("添加病人信息");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(61:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Patient"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("查看病人信息");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(66:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/Patient"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("添加预约信息");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(71:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Diagnoses"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("患者查询预约医生");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(77:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/patient_to_doctor"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("医生登陆");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(83:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/DoctorPage"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("患者登陆");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(88:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/PatientPage"
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("医生查看患者");
            Button.debugLine("entry/src/main/ets/pages/Index.ets(93:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/doctor_to_patient"
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
