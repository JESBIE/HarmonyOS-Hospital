export class DoctorModel {
    id?: number;
    name: string = "";
    age?: number;
    salary?: number;
    level?: string;
    group_id?: number;
}
