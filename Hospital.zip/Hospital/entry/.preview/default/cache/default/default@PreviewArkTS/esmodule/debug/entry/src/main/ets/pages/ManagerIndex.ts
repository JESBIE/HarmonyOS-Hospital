if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ManagerIndex_Params {
    Doctors?: DoctorModel[];
    addDoctor?;
    deleteDoctor?;
    findDoctorDB?;
}
import router from "@ohos:router";
import type relationalStore from "@ohos:data.relationalStore";
import { DButil } from "@normalized:N&&&entry/src/main/ets/Util/DButils&";
import type { DoctorModel } from '../viewmodel/DoctorModel';
class ManagerIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__Doctors = new ObservedPropertyObjectPU([], this, "Doctors");
        this.addDoctor = () => {
            const valueBucket: relationalStore.ValuesBucket = {
                'NAME': "往佳节",
                'AGE': 12,
                'SALARY': 200,
                'LEVEL': "11",
                'GROUP_ID': 1
            };
            DButil.insertDB('Doctor', valueBucket);
        };
        this.deleteDoctor = () => {
            DButil.deleteDB('Doctor', 1);
        };
        this.findDoctorDB = async () => {
            this.Doctors = await DButil.queryDB(['ID', 'NAME', 'AGE', 'SALARY', 'LEVEL', 'GROUP_ID'], 'Doctor');
            console.log(`数据库的结果为${JSON.stringify(this.Doctors)}`);
        };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ManagerIndex_Params) {
        if (params.Doctors !== undefined) {
            this.Doctors = params.Doctors;
        }
        if (params.addDoctor !== undefined) {
            this.addDoctor = params.addDoctor;
        }
        if (params.deleteDoctor !== undefined) {
            this.deleteDoctor = params.deleteDoctor;
        }
        if (params.findDoctorDB !== undefined) {
            this.findDoctorDB = params.findDoctorDB;
        }
    }
    updateStateVars(params: ManagerIndex_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__Doctors.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__Doctors.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __Doctors: ObservedPropertyObjectPU<DoctorModel[]>;
    get Doctors() {
        return this.__Doctors.get();
    }
    set Doctors(newValue: DoctorModel[]) {
        this.__Doctors.set(newValue);
    }
    private addDoctor;
    private deleteDoctor;
    aboutToAppear(): void {
        this.findDoctorDB();
    }
    private findDoctorDB;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(39:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor('#F0FFFF');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(42:7)", "entry");
            Column.backgroundColor('#ccffcc');
            Column.width('95%');
            Column.height(120);
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(43:9)", "entry");
            Row.padding({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(44:11)", "entry");
            Image.width(40);
            Image.height(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("护士");
            Text.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(47:11)", "entry");
            Text.fontSize(35);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(51:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(52:11)", "entry");
            Image.width(40);
            Image.height(40);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Nurse"
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(61:11)", "entry");
            Image.width(47);
            Image.height(47);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(66:11)", "entry");
            Image.width(36);
            Image.height(36);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(72:11)", "entry");
            Image.width(35);
            Image.height(35);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/Nurse"
                });
            });
        }, Image);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(92:7)", "entry");
            Column.backgroundColor('#ffcccc');
            Column.width('95%');
            Column.height(120);
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(93:9)", "entry");
            Row.padding({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(94:11)", "entry");
            Image.width(40);
            Image.height(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("医生");
            Text.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(97:11)", "entry");
            Text.fontSize(35);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(101:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(102:11)", "entry");
            Image.width(40);
            Image.height(40);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/get_Doctor"
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(112:11)", "entry");
            Image.width(47);
            Image.height(47);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/delete_Doctor"
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(121:11)", "entry");
            Image.width(36);
            Image.height(36);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/updata_Doctor"
                });
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(130:11)", "entry");
            Image.width(35);
            Image.height(35);
            Image.onClick(this.findDoctorDB);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/Doctor"
                });
            });
        }, Image);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(149:7)", "entry");
            Column.backgroundColor('#FFFACD');
            Column.width('95%');
            Column.height(120);
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(150:9)", "entry");
            Row.padding({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(151:11)", "entry");
            Image.width(40);
            Image.height(40);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("病患");
            Text.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(154:11)", "entry");
            Text.fontSize(35);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(158:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.hospital", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(160:11)", "entry");
            Image.width(35);
            Image.height(35);
            Image.onClick(this.findDoctorDB);
            Image.onClick(() => {
                router.pushUrl({
                    url: "pages/Patient"
                });
            });
        }, Image);
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel("查看病患人数统计");
            Button.debugLine("entry/src/main/ets/pages/ManagerIndex.ets(177:7)", "entry");
            Button.onClick(() => {
                router.pushUrl({
                    url: "pages/Patient_count"
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ManagerIndex";
    }
}
registerNamedRoute(() => new ManagerIndex(undefined, {}), "", { bundleName: "com.example.hospital", moduleName: "entry", pagePath: "pages/ManagerIndex", pageFullPath: "entry/src/main/ets/pages/ManagerIndex", integratedHsp: "false", moduleType: "followWithHap" });
