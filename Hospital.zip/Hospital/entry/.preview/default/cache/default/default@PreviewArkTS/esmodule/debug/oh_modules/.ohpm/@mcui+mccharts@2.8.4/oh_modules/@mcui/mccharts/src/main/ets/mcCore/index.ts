import Charts from "@normalized:N&&&@mcui/mccharts/src/main/ets/mcCore/class/charts.class&2.8.4";
export default Charts;
