export class MissionLogModel {
    log_id?: number;
    mid?: number;
    log_time?: string;
    details?: string;
}
