import Charts from './class/charts.class'


export default Charts