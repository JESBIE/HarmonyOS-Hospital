// import { WordCloud } from './wordCloud'
// /**
//  * 词云图
//  */
// class DrawWordCloud {
//   constructor (elements, offCanvas, options) {
//     // super('wordCloud');
//     WordCloud(elements, offCanvas, options)
//   }
//   create() {
//
//   }
//   initData() {
//
//   }
//   animate() {
//
//   }
// }
//
// export default DrawWordCloud